<?php
/** Server-side throttling, atomic locks, and bounded usage diagnostics for AI endpoints. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JLuxe_AI_Request_Guard {
    public static function acquire( string $action, int $product_id = 0 ) {
        $user_id = get_current_user_id();
        if ( ! $user_id ) { return new WP_Error( 'jpi_guard_auth', 'نشست کاربری معتبر نیست.', array( 'status' => 401 ) ); }
        $action = sanitize_key( $action );
        $lock_key = 'jpi_ai_lock_' . $action . '_' . ( $product_id ?: 'global_' . $user_id );
        $existing = get_option( $lock_key, false );
        if ( is_numeric( $existing ) && (int) $existing < time() - 15 * MINUTE_IN_SECONDS ) { delete_option( $lock_key ); }
        if ( ! add_option( $lock_key, time(), '', false ) ) { return new WP_Error( 'jpi_guard_busy', 'برای این محصول/عملیات درخواست دیگری در حال اجراست؛ پس از پایان آن دوباره تلاش کنید.', array( 'status' => 409 ) ); }
        $minute_key = 'jpi_ai_10m_' . $user_id;
        $daily_key  = 'jpi_ai_day_' . $user_id . '_' . gmdate( 'Ymd' );
        $minute = (int) get_transient( $minute_key );
        $daily  = (int) get_transient( $daily_key );
        if ( $minute >= 5 || $daily >= 40 ) {
            delete_option( $lock_key );
            return new WP_Error( 'jpi_guard_limit', $minute >= 5 ? 'حداکثر ۵ درخواست AI در هر ۱۰ دقیقه مجاز است.' : 'سقف ۴۰ درخواست AI روزانه برای حساب شما تکمیل شده است.', array( 'status' => 429 ) );
        }
        set_transient( $minute_key, $minute + 1, 10 * MINUTE_IN_SECONDS );
        set_transient( $daily_key, $daily + 1, DAY_IN_SECONDS );
        register_shutdown_function( static function() use ( $lock_key ) { delete_option( $lock_key ); } );
        return array( 'lock_key' => $lock_key );
    }

    public static function log_usage( string $action, int $product_id, string $provider, string $model, float $started_at, string $status, int $input_chars = 0 ): void {
        $rows = get_option( 'jpi_ai_usage_log', array() );
        if ( ! is_array( $rows ) ) { $rows = array(); }
        $rows[] = array(
            'time' => time(), 'user_id' => get_current_user_id(), 'action' => sanitize_key( $action ),
            'product_id' => absint( $product_id ), 'provider' => sanitize_text_field( $provider ),
            'model' => sanitize_text_field( $model ), 'duration_ms' => max( 0, (int) round( ( microtime( true ) - $started_at ) * 1000 ) ),
            'status' => sanitize_key( $status ), 'input_chars' => max( 0, $input_chars ),
        );
        update_option( 'jpi_ai_usage_log', array_slice( $rows, -100 ), false );
    }
}
