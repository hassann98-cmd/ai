// Dependency-free smoke tests for the admin parser. Run with: node tests/parser-smoke.js
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const importerSource = fs.readFileSync(__dirname + '/../assets/importer.js', 'utf8');
const rankMathApply = importerSource.slice(importerSource.indexOf('async function applyRankMath('), importerSource.indexOf('function isElementVisible('));
assert(rankMathApply.indexOf('editButton.click()') < rankMathApply.indexOf('await applyRankMathBreadcrumb(seo.breadcrumb'), 'Snippet editor must open before breadcrumb is applied.');
assert(rankMathApply.indexOf("if(seo.description)") < rankMathApply.indexOf('await applyRankMathBreadcrumb(seo.breadcrumb'), 'Breadcrumb must be applied after the other snippet fields.');
assert(rankMathApply.indexOf('closeRankMathSnippetEditor()') < rankMathApply.indexOf('await applyRankMathBreadcrumb(seo.breadcrumb'), 'Snippet modal must close before the sidebar breadcrumb field is updated.');
const breadcrumbRoutine = importerSource.slice(importerSource.indexOf('async function applyRankMathBreadcrumb('), importerSource.indexOf('async function applyRankMath('));
assert(breadcrumbRoutine.includes('await activateRankMathAdvanced()'), 'The advanced Rank Math tab must be activated before filling breadcrumb.');
assert(importerSource.includes('.rank-math-breadcrumb-title input[id^="inspector-text-control-"]'), 'Breadcrumb selector should prefer Rank Math breadcrumb wrapper.');

const noop = { length: 1, on(){return this;}, val(){return '';}, prop(){return this;}, text(){return this;}, empty(){return this;}, append(){return this;}, is(){return false;} };
function $(selector){ return Object.assign({}, noop); }
const labels=['اماهوم','لیمون'].map(textContent=>({textContent}));
class DOMParserMock {
  parseFromString(source){
    let html=String(source);
    const decode=x=>String(x).replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#039;/g,"'");
    const strip=x=>decode(String(x).replace(/<[^>]*>/g,''));
    return {
      querySelectorAll(selector){
        if(selector==='tr'){
          const rows=[];const re=/<tr\b[^>]*>[\s\S]*?<\/tr>/gi;let m;
          while((m=re.exec(html))!==null){const original=m[0],cells=Array.from(original.matchAll(/<(?:th|td)\b[^>]*>([\s\S]*?)<\/(?:th|td)>/gi)).map(c=>({textContent:strip(c[1])}));
            rows.push({querySelectorAll(){return cells;},replaceWith(node){html=html.replace(original,node.textContent);}});
          }
          return rows;
        }
        if(selector==='script,style,noscript,template,svg,iframe,object,button,input,select,textarea'){
          html=html.replace(/<(script|style|noscript|template|svg|iframe|object|button|input|select|textarea)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<(input|br)\b[^>]*\/?\s*>/gi,'');
        }
        return [];
      },
      body:{get textContent(){return strip(html.replace(/<br\b[^>]*>/gi,'\n').replace(/<\/(p|div|li|h[1-6]|section|article)\s*>/gi,'\n'));}}
    };
  }
}
const document={
  addEventListener(){},
  querySelectorAll(selector){ return selector.includes('product_brandchecklist')?labels:[]; },
  createTextNode(textContent){return {textContent};},
  createElement(){ const el={value:''}; Object.defineProperty(el,'innerHTML',{set(v){el.value=String(v).replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');}}); return el; }
};
const context={window:{},document,DOMParser:DOMParserMock,jQuery:$,console,Event:function(){},navigator:{clipboard:{writeText:async()=>{}}},setTimeout};
context.window=context;
vm.runInNewContext(fs.readFileSync(__dirname+'/../assets/importer.js','utf8'),context);

const brief=`&lt;input type="text" name="post_title" size="30" value="" id="title"&gt; ۱. تایتل اصلی محصول (بالای صفحه وردپرس)
آباژور رومیزی چوب گردو مدل سهند برند اماهوم (پایه گوی چوبی و کلاهک کنفی)

۲. توضیحات جامع محصول (Product Description)
توضیح معرفی محصول.

جدول مشخصات فنی و ابعاد
**مشخصه فنیتوضیحات و مقادیرنام مدل و طرح**
مدل سهند (طرح پایه گوی خراطی‌شده)
**برند سازنده**
اماهوم (Amahome)
**ارتفاع کل (سانتی‌متر)**۳۰.۵ سانتی‌متر**قطر پایه (سانتی‌متر)**۱۲.۷ سانتی‌متر**قطر کلاهک (سانتی‌متر)**۲۱.۵ سانتی‌متر
**جنس پایه و گوی‌ها**
۱۰۰٪ چوب طبیعی گردو (توپر)
**جنس و طرح کلاهک (شید)**
بافت عمودی نخ کنفی طبیعی
**سیم و کلید**
دارد (مجهز به سیم و کلید بین‌راهی)
**مکان‌های پیشنهادی استفاده**
روی میز پاتختی، میز عسلی، کنسول و کتابخانه

سوالات متداول خریداران
**۱. آیا گوی‌های پایه محکم هستند؟** بله؛ گوی‌ها به‌صورت مستحکم فیکس شده‌اند.
**۲. آیا محصول سیم و کلید دارد؟** بله، دارای سیم و کلید استاندارد است.
**۳. چه لامپی مناسب است؟** لامپ LED آفتابی پیشنهاد می‌شود.
**۴. پایه از چه جنسی است؟** از چوب طبیعی گردو ساخته شده است.

جمع‌بندی محصول.

۳. دسته‌بندی محصول در ووکامرس
- **دسته اصلی (Make Term Primary):** \`دکوراسیون و تزیینات\` &gt; \`آباژور، اکسسوری و دکوری\`

۴. جدول ویژگی‌ها برای تب «اطلاعات محصول / مشخصات فنی» وردپرس
**نام ویژگیمقدار ویژگی**مشخصه و مدل
آباژور رومیزی مدل سهند (پایه گوی چوبی)

۵. ویژگی‌های مهم برای تعریف در بخش ویژگی‌های وردپرس (حداکثر ۴ مورد)
1. **مدل و ارتفاع:** مدل سهند (طرح گوی) - ارتفاع ۳۰.۵ سانتی‌متر
2. **جنس و قطر پایه:** چوب گردو طبیعی (قطر ۱۲.۷ سانتی‌متر)
3. **جنس و قطر کلاهک:** کنفی استوانه‌ای (قطر ۲۱.۵ سانتی‌متر)
4. **سیم و کلید:** دارد

۶. توضیحات کوتاه محصول (Short Description)
خلاصهٔ محصول.

۷. برچسب‌های محصول (Tags)
آباژور سهند,آباژور گوی چوبی

۸. تنظیمات افزونه Rank Math Pro (Snippet Editor)
- کلمه کلیدی اصلی: \`آباژور چوب گردو مدل سهند اماهوم\`
- کلمات کلیدی فرعی: \`آباژور پایه گوی چوبی\` ، \`آباژور سهند چوب گردو\`
- **Title (عنوان سئو - ۵۹ کاراکتر):**\`خرید آباژور مدل سهند | جهیزیه لوکس\`
- **Description (توضیحات متا):**\`خرید آباژور مدل سهند با پایه گوی چوبی.\`
- **Breadcrumb Title (عنوان مسیر راهنما):**\`آباژور چوب گردو مدل سهند اماهوم ----\`

۹. متن جایگزین تصاویر (Alt Text)
1. **تصویر ۱ (عکس روشن روی میز پاتختی):** \`آباژور سهند روی میز پاتختی\``;
const result=context.JLuxeProductImportParser.parse(brief);
const latinSlugResult=context.JLuxeProductImportParser.parse(JSON.stringify({title:'آباژور چوب گردو مدل سهند اماهوم',seo:{permalink:'Walnut Wood Table Lamp / Sahand Amahome'}}));
assert.strictEqual(latinSlugResult.title,'آباژور چوب گردو مدل سهند اماهوم','Persian product title must remain unchanged when the permalink is English.');
assert.strictEqual(latinSlugResult.seo.permalink,'walnut-wood-table-lamp-sahand-amahome','Permalink must be normalized to a lowercase ASCII slug.');
const persianSlugResult=context.JLuxeProductImportParser.parse(JSON.stringify({title:'آباژور چوب گردو مدل سهند اماهوم',seo:{permalink:'آباژور-چوب-گردو'}}));
assert.strictEqual(persianSlugResult.seo.permalink,'','A Persian slug must not be passed into the English permalink field.');
assert.strictEqual(result.title,'آباژور رومیزی چوب گردو مدل سهند برند اماهوم (پایه گوی چوبی و کلاهک کنفی)');
assert.strictEqual(result.faqs.length,4,'Persian question marks must be recognized in bold FAQ questions.');
assert.strictEqual(result.faqs[0].question,'آیا گوی‌های پایه محکم هستند؟');
assert(!result.description.includes('سوالات متداول'),'Extracted FAQ content should not remain duplicated in the long description.');
assert(!result.description.includes('جدول مشخصات فنی'),'The technical table routed to grouped specs should be removed from long description.');
assert.strictEqual(result.specs.length,1);
const specMap=Object.fromEntries(result.specs[0].items.map(x=>[x.label,x.value]));
assert.strictEqual(specMap['مدل و طرح'],'مدل سهند (طرح پایه گوی خراطی‌شده)');
assert.strictEqual(specMap['ارتفاع کل (سانتی‌متر)'],'۳۰.۵ سانتی‌متر');
assert.strictEqual(specMap['قطر پایه (سانتی‌متر)'],'۱۲.۷ سانتی‌متر');
assert(specMap['مکان‌های پیشنهادی استفاده'].includes('میز پاتختی'));
assert.strictEqual(result.categories[0],'دکوراسیون و تزیینات > آباژور، اکسسوری و دکوری');
assert.strictEqual(result.brand,'اماهوم');
assert.strictEqual(result.attributes.length,4);
assert.strictEqual(result.seo.title,'خرید آباژور مدل سهند | جهیزیه لوکس');
assert.strictEqual(result.seo.breadcrumb,'آباژور چوب گردو مدل سهند اماهوم','Breadcrumb label/value formatting should be parsed and trailing separator dashes removed.');
assert.strictEqual(result.image_alts[0],'آباژور سهند روی میز پاتختی');
const inlineCase=`&lt;input type="text" name="post_title" value="" id="title"&gt; ۱. تایتل اصلی محصول (بالای صفحه وردپرس)
آباژور نمونه مدل سهند
۲. توضیحات جامع محصول (Product Description)
متن بلند معرفی محصول.
توضیحات محصولم اینجا ست ۶. توضیحات کوتاه محصول (Short Description)
خلاصهٔ کوتاه محصول.`;
const tableHtml=context.JLuxeProductImportParser.toHtml('## مشخصات فنی\n\n| ویژگی | مقدار |\n| --- | --- |\n| ارتفاع | ۳۰ سانتی‌متر |\n| نوع | <script>alert(1)</script> |');
assert(tableHtml.includes('<table><thead><tr><th>ویژگی</th><th>مقدار</th></tr></thead><tbody>'));
assert(tableHtml.includes('<td>ارتفاع</td><td>۳۰ سانتی‌متر</td>'));
assert(tableHtml.includes('&lt;script&gt;alert(1)&lt;/script&gt;') && !tableHtml.includes('<script>'), 'Table cell HTML must be escaped before output.');
const inlineResult=context.JLuxeProductImportParser.parse(inlineCase);
assert.strictEqual(inlineResult.title,'آباژور نمونه مدل سهند','Title parser must skip a preceding escaped HTML input element.');
assert.strictEqual(inlineResult.description,'متن بلند معرفی محصول.','Short-description heading glued to the preceding sentence must split cleanly.');
assert.strictEqual(inlineResult.short_description,'خلاصهٔ کوتاه محصول.');
const shortSpecCase=`۱. تایتل اصلی محصول (بالای صفحه وردپرس)\nظرف نمونه\n۲. توضیحات جامع محصول (Product Description)\nمتن معرفی.\n۶. توضیحات کوتاه محصول (Short Description)\nابعاد: ۱۲ × ۲۰ سانتی‌متر\nوزن: ۵۰۰ گرم`;
const shortSpecResult=context.JLuxeProductImportParser.parse(shortSpecCase);
const shortSpecMap=Object.fromEntries((shortSpecResult.specs[0]||{items:[]}).items.map(x=>[x.label,x.value]));
assert.strictEqual(shortSpecMap['ابعاد'],'۱۲ × ۲۰ سانتی‌متر','Explicit dimensions in short description must also populate grouped specs.');
assert.strictEqual(shortSpecMap['وزن'],'۵۰۰ گرم','Explicit weight in short description must also populate grouped specs.');
assert(shortSpecResult.short_description.includes('ابعاد:'),'Spec extraction must not erase the original short description.');

const pastedHtml=`<input type="text" id="title" value="" data-path-to-node="form.title">
<h2>۱. تایتل اصلی محصول</h2><p>آباژور HTML سهند اماهوم</p>
<h2>۲. توضیحات جامع محصول (Product Description)</h2>
<p id="p-rc_123" data-path-to-node="content.description"><span>توضیح تمیز محصول.</span></p>
<h3>جدول مشخصات فنی</h3>
<p>جدول ویژگی‌ها برای تب «اطلاعات محصول / مشخصات فنی»</p>
<table><thead><tr><th>نام ویژگی</th><th>مقدار ویژگی</th></tr></thead><tbody>
<tr><td>مشخصه و سایز</td><td>مدل سهند، سایز کوچک</td></tr><tr><td>جنس پایه</td><td>چوب گردو</td></tr>
</tbody></table>
<h2>۳. دسته‌بندی محصول</h2><p>دکوراسیون</p>`;
const htmlResult=context.JLuxeProductImportParser.parse(pastedHtml);
assert.strictEqual(htmlResult.title,'آباژور HTML سهند اماهوم');
assert.strictEqual(htmlResult.specs[0].group,'مشخصات فنی','Instructional tab heading must not become the specification group name.');
const htmlSpecMap=Object.fromEntries(htmlResult.specs[0].items.map(x=>[x.label,x.value]));
assert.strictEqual(htmlSpecMap['مشخصه و سایز'],'مدل سهند، سایز کوچک','Exact generic table labels must be preserved.');
assert.strictEqual(htmlSpecMap['جنس پایه'],'چوب گردو');
assert(!htmlResult.description.includes('data-path-to-node'));
assert(!htmlResult.description.includes('p-rc_123'));
assert(!htmlResult.description.includes('جدول ویژگی‌ها'));

console.log(JSON.stringify({title:result.title,faqCount:result.faqs.length,specCount:result.specs[0].items.length,attributes:result.attributes.length,category:result.categories[0],brand:result.brand,htmlSpecCount:htmlResult.specs[0].items.length},null,2));
