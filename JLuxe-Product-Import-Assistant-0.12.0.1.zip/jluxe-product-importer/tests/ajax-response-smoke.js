// Test non-JSON admin-ajax diagnostics without a browser. Run with: node tests/ajax-response-smoke.js
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(__dirname + '/../assets/importer.js', 'utf8');
const start = source.indexOf('async function readAjaxJson(');
const end = source.indexOf('async function runContentDraft(', start);
assert(start >= 0 && end > start, 'AJAX response parser must be present.');
const snippet = source.slice(start, end) + '\nglobalThis.readAjaxJson = readAjaxJson;';
const context = { JSON, Error };
vm.runInNewContext(snippet, context);
(async () => {
  const parsed = await context.readAjaxJson({ status: 200, text: async () => '{"success":true,"data":{}}' }, 'Generate');
  assert.strictEqual(parsed.success, true, 'Valid WordPress JSON should still parse.');
  await assert.rejects(
    context.readAjaxJson({ status: 403, text: async () => '<!DOCTYPE html><html><head><title>Access Denied</title></head></html>' }, 'Generate'),
    /HTTP 403.*Access Denied.*فایروال/,
    'HTML responses should produce a useful status/title diagnostic rather than Unexpected token JSON errors.'
  );
  console.log('AJAX response diagnostics smoke checks passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
