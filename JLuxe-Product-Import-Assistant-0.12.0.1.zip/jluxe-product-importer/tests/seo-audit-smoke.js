// Read-only product-content audit checks. Run with: node tests/seo-audit-smoke.js
const fs = require('fs');
const assert = require('assert');
const source = fs.readFileSync(__dirname + '/../includes/class-jluxe-seo-audit.php', 'utf8');
assert(source.includes('private function repeated_content_warnings'), 'The audit must expose the same-page repeated-block heuristic.');
assert(source.includes("preg_split( '/<\\/(?:p|li|h[1-6]|div|tr)>/i'"), 'The heuristic should inspect semantic HTML content blocks.');
assert(source.includes("hash( 'sha256', $normalized )"), 'Repeated blocks should be detected by normalized exact-match hashes.');
assert(source.includes("$length < 100"), 'Short labels and headings should not trigger duplicate-content warnings.');
assert(source.includes("$audit['content_warnings']"), 'Content warnings should appear in the audit and incomplete filter.');
assert(source.includes('شباهت معنایی کامل'), 'The interface must clarify this is not a ranking/quality score.');
console.log('SEO audit smoke checks passed.');
