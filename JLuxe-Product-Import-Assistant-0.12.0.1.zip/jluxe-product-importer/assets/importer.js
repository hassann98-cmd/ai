(function ($) {
  'use strict';

  const $app = $('.jluxe-import-app');
  if (!$app.length) return;
  const $source = $('#jluxe-import-source');
  const $preview = $('#jluxe-import-preview');
  const $warnings = $('#jluxe-import-warnings');
  let parsed = null;

  const $id = (id) => document.getElementById(id);
  if (window.location && window.location.hash === '#jpi-seo-draft-section') {
    const target = $id('jpi-seo-draft-section');
    const box = target && target.closest('.postbox');
    if (box && box.classList.contains('closed')) {
      const toggle = box.querySelector('.handlediv');
      if (toggle) toggle.click();
    }
    window.setTimeout(() => {
      openModal('jpi-auto-modal', $id('jpi-open-auto-modal'));
      const modal = $id('jpi-auto-modal');
      if (modal) modal.scrollTop = 0;
    }, 250);
  }
  let activeModal = null;
  let modalReturnFocus = null;
  function modalFocusable(modal) {
    return Array.from(modal.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(el => !el.hidden && !el.closest('[hidden]') && el.getAttribute('aria-hidden') !== 'true');
  }
  function openModal(id, trigger) {
    const modal = $id(id);
    if (!modal) return;
    if (activeModal) closeModal(activeModal, false);
    modalReturnFocus = trigger || document.activeElement;
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    activeModal = modal;
    document.body.classList.add('jpi-modal-open');
    const dialog = modal.querySelector('[role="dialog"]');
    if (dialog) dialog.focus();
  }
  function closeModal(modal, restoreFocus) {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    if (activeModal === modal) activeModal = null;
    if (!activeModal) document.body.classList.remove('jpi-modal-open');
    if (restoreFocus !== false && modalReturnFocus && document.contains(modalReturnFocus)) modalReturnFocus.focus();
  }
  $('#jpi-open-manual-modal').on('click', function(){
    $('#jpi-manual-modal-title').text('ورود متن یا بازبینی محتوا');
    $('#jpi-manual-source').prop('hidden',false);
    openModal('jpi-manual-modal',this);
  });
  $('#jpi-open-auto-modal').on('click', function(){openModal('jpi-auto-modal',this);});
  $(document).on('click','[data-jpi-modal-close]',function(){closeModal(this.closest('.jpi-modal'));});
  document.addEventListener('keydown',function(event){
    if(!activeModal)return;
    if(event.key==='Escape'){event.preventDefault();closeModal(activeModal);return;}
    if(event.key!=='Tab')return;
    const items=modalFocusable(activeModal);
    if(!items.length){event.preventDefault();return;}
    const first=items[0],last=items[items.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  });
  const txt = (v) => String(v == null ? '' : v).trim();
  const englishSlug = (v) => String(v == null ? '' : v).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  const blank = () => ({ title:'', description:'', short_description:'', categories:[], brand:'', tags:[], specs:[], attributes:[], faqs:[], keywords:[], seo:{title:'',permalink:'',description:'',breadcrumb:''}, image_alts:[] });

  function normDigits(s) {
    const map = {'۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9','٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9'};
    return String(s || '').replace(/[۰-۹٠-٩]/g, c => map[c]);
  }
  function norm(s) {
    return normDigits(String(s || '').toLowerCase())
      .replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[ۀة]/g,'ه')
      .replace(/[\u064B-\u065F\u0670\u0640]/g,'')
      .replace(/[“”"'`*_~]/g,'').replace(/[()\[\]{}،؛,:.!؟?]/g,' ')
      .replace(/\s+/g,' ').trim();
  }
  function decodeEntities(s) {
    const el = document.createElement('textarea'); el.innerHTML = String(s || ''); return el.value;
  }
  function htmlToText(s) {
    // Keep semantic emphasis for FAQ parsing, but discard copied UI/editor artifacts.
    const source=String(s||'').replace(/<(strong|b)\b[^>]*>([\s\S]*?)<\/\1>/gi,'**$2**');
    const doc = new DOMParser().parseFromString(source, 'text/html');
    doc.querySelectorAll('script,style,noscript,template,svg,iframe,object,button,input,select,textarea').forEach(x => x.remove());
    doc.querySelectorAll('br').forEach(x => x.replaceWith('\n'));
    // A copied HTML table is serialized row-by-row so key/value cells stay paired.
    doc.querySelectorAll('tr').forEach(tr => {
      const cells = Array.from(tr.querySelectorAll('th,td')).map(c => (c.textContent || '').replace(/\s+/g,' ').trim());
      tr.replaceWith(document.createTextNode(cells.join(' | ') + '\n'));
    });
    doc.querySelectorAll('p,div,li,h1,h2,h3,h4,h5,h6,section,article').forEach(x => x.append('\n'));
    return (doc.body.textContent || '').replace(/\r/g,'').replace(/[\t\u00a0]+/g,' ').replace(/\n[ \t]+/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function cleanLine(s) {
    return decodeEntities(String(s || '').replace(/<\/?(?:strong|b|em|i|span|p|div|li|h[1-6])\b[^>]*>/gi,' '))
      .replace(/\*\*/g,'').replace(/__([^_]+)__/g,'$1').replace(/^\s*(?:[-*•▪]+|\d+[.)]|[۰-۹٠-٩]+[.)])\s*/,'').trim();
  }
  function splitLines(s) { return String(s || '').replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean); }
  function deMarkdown(s) {
    return String(s || '').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,' ')
      .replace(/\*\*(.*?)\*\*/g,'$1').replace(/__(.*?)__/g,'$1').replace(/\*(.*?)\*/g,'$1').replace(/_(.*?)_/g,'$1')
      .replace(/`([^`]+)`/g,'$1').replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g,'$1 ($2)').trim();
  }
  function toHtml(markdown) {
    // Conservative Markdown rendering with explicit table handling; all cell content is escaped first.
    const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/__(.+?)__/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>').replace(/_(.+?)_/g,'<em>$1</em>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" rel="nofollow">$1</a>');
    const lines = String(markdown || '').replace(/\r/g,'').split('\n');
    const out=[]; let para=[]; let ul=false; let ol=false;
    const flush=()=>{ if(para.length){out.push('<p>'+para.map(inline).join('<br>')+'</p>');para=[];} };
    const closeLists=()=>{ if(ul){out.push('</ul>');ul=false;} if(ol){out.push('</ol>');ol=false;} };
    const cells=line=>{let value=String(line||'').trim();if(value.startsWith('|'))value=value.slice(1);if(value.endsWith('|'))value=value.slice(0,-1);return value.split('|').map(x=>x.trim());};
    const separator=line=>/^\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?$/.test(String(line||'').trim());
    for(let i=0;i<lines.length;){
      const t=lines[i].trim();
      if(t.includes('|')&&i+1<lines.length&&separator(lines[i+1])){
        flush();closeLists();
        const headers=cells(lines[i]);i+=2;const rows=[];
        while(i<lines.length&&lines[i].trim().includes('|')&&lines[i].trim()){
          const row=cells(lines[i]);if(row.length)rows.push(row);i++;
        }
        out.push('<table><thead><tr>'+headers.map(cell=>'<th>'+inline(cell)+'</th>').join('')+'</tr></thead><tbody>');
        rows.forEach(row=>{out.push('<tr>'+headers.map((_,index)=>'<td>'+inline(row[index]||'')+'</td>').join('')+'</tr>');});
        out.push('</tbody></table>');continue;
      }
      if(!t){flush();closeLists();i++;continue;}
      const h=t.match(/^(#{1,4})\s+(.+)$/); if(h){flush();closeLists();const level=h[1].length+1;out.push('<h'+level+'>'+inline(h[2])+'</h'+level+'>');i++;continue;}
      const u=t.match(/^[-*•]\s+(.+)$/); const o=t.match(/^\d+[.)]\s+(.+)$/);
      if(u){flush();if(ol){out.push('</ol>');ol=false;}if(!ul){out.push('<ul>');ul=true;}out.push('<li>'+inline(u[1])+'</li>');i++;continue;}
      if(o){flush();if(ul){out.push('</ul>');ul=false;}if(!ol){out.push('<ol>');ol=true;}out.push('<li>'+inline(o[1])+'</li>');i++;continue;}
      closeLists();para.push(t);i++;
    }
    flush();closeLists();return out.join('\n');
  }
  function readableSource(input) {
    const decoded=decodeEntities(String(input||''));
    return /<[a-z][^>]*>/i.test(decoded)?htmlToText(decoded):decoded;
  }
  function parseHeadingSections(input) {
    const source=readableSource(input).replace(/\r/g,'');
    const isMajorHeading=(h)=>/تایتل اصلی|عنوان اصلی محصول|نام محصول|توضیحات جامع محصول|product description|دسته.?بندی محصول|جدول (?:ویژگی|مشخصات)|ویژگی.?های مهم برای تعریف|ویژگی.?های وردپرس|توضیحات کوتاه محصول|short description|برچسب.?های محصول|تنظیمات افزونه rank math|rank math pro|متن جایگزین تصاویر|alt text/i.test(norm(h));
    // Scan markers anywhere, not only at the start of a line. This handles pasted HTML
    // attributes before section 1 and a section label appended to the end of the previous paragraph.
    const marker=/(?:^|[^0-9۰-۹٠-٩])([0-9۰-۹٠-٩]{1,2})\s*[.)،-]\s*/g;
    const found=[];let m;
    while((m=marker.exec(source))!==null){
      const numberAt=m.index+m[0].lastIndexOf(m[1]);
      const markerEnd=m.index+m[0].length;
      const newline=source.indexOf('\n',markerEnd);
      const lineEnd=newline<0?source.length:newline;
      const candidate=source.slice(markerEnd,lineEnd).replace(/\*\*/g,' ').replace(/^\s*#{1,6}\s*/,'').trim();
      if(isMajorHeading(candidate)) found.push({start:numberAt,bodyStart:newline<0?markerEnd:newline+1,heading:candidate});
    }
    return found.map((section,index)=>({heading:section.heading,body:source.slice(section.bodyStart,index+1<found.length?found[index+1].start:source.length).trim()}));
  }
  function sectionBy(sections, rx) { const s=sections.find(x=>rx.test(norm(x.heading))); return s ? s.body : ''; }
  function parseFaqs(text) {
    const out=[]; const src=String(text||'');
    // Supports bold numbered Q/A, plain numbered Q/A, and Q/A rows separated by a pipe.
    const bold=/\*\*\s*(?:سوال\s*\d*\s*[:：-]?\s*)?(?:[0-9۰-۹٠-٩]+\s*[.)-]\s*)?(.+?[؟?])\s*\*\*\s*([\s\S]*?)(?=(?:\n\s*\*\*\s*(?:[0-9۰-۹٠-٩]+\s*[.)-])|$))/g;
    let m; while((m=bold.exec(src))!==null){ const q=deMarkdown(m[1]).trim(), a=deMarkdown(m[2]).trim(); if(q.length>5&&a.length>2) out.push({question:q,answer:a}); }
    if(out.length) return dedupeFaq(out);
    splitLines(src).forEach(line=>{
      let x=line.replace(/^\*\*/,'').replace(/\*\*$/,'').trim();
      let m=x.match(/^(?:[0-9۰-۹٠-٩]+[.)]\s*)?(.+?[؟?])\s*(?:\*\*)?\s*(?:[-–—:]\s*|\s{2,})(.+)$/);
      if(!m && x.includes('|')) { const p=x.split('|').map(deMarkdown).map(t=>t.trim()); if(p.length>=2&&/[؟?]/.test(p[0])) m=[null,p[0],p.slice(1).join(' | ')]; }
      if(m){ const q=deMarkdown(m[1]).trim(),a=deMarkdown(m[2]).trim(); if(q.length>5&&a.length>2)out.push({question:q,answer:a}); }
    });
    return dedupeFaq(out);
  }
  function dedupeFaq(items){const seen=new Set();return items.filter(x=>{const k=norm(x.question);if(seen.has(k))return false;seen.add(k);return true;});}
  function parseBoldSpecTable(text, groupName) {
    const definitions=[
      {label:'مدل و طرح',aliases:['نام مدل و طرح','مشخصه و مدل','مدل و طرح']},
      {label:'برند سازنده',aliases:['برند سازنده']},
      {label:'ارتفاع کل (سانتی‌متر)',aliases:['ارتفاع کل (سانتی‌متر)','ارتفاع کل','ارتفاع (سانتی‌متر)']},
      {label:'قطر پایه (سانتی‌متر)',aliases:['قطر پایه (سانتی‌متر)','قطر پایه']},
      {label:'قطر کلاهک (سانتی‌متر)',aliases:['قطر کلاهک (سانتی‌متر)','قطر کلاهک']},
      {label:'جنس پایه',aliases:['جنس پایه و گوی‌ها','جنس پایه و گوی ها','جنس پایه']},
      {label:'جنس و طرح کلاهک',aliases:['جنس و طرح کلاهک (شید)','جنس کلاهک (شید)','جنس و طرح کلاهک','جنس کلاهک']},
      {label:'سیم و کلید',aliases:['سیم و کلید']},
      {label:'مکان‌های پیشنهادی استفاده',aliases:['مکان‌های پیشنهادی استفاده','مکان های پیشنهادی استفاده']}
    ];
    const tokens=String(text||'').split('**'); const found=new Map();
    for(let i=1;i<tokens.length;i+=2){
      const bold=norm(tokens[i]);
      const candidates=definitions.map(def=>({def,match:def.aliases.map(norm).sort((a,b)=>b.length-a.length).find(a=>a&&bold.includes(a))})).filter(x=>x.match).sort((a,b)=>b.match.length-a.match.length);
      if(!candidates.length)continue;
      const def=candidates[0].def;
      let value=deMarkdown(tokens[i+1]||'').replace(/^[\s:：|–—-]+|[\s|]+$/g,'').trim();
      value=value.split(/\n\s*\n/)[0].trim();
      if(value && !found.has(def.label))found.set(def.label,{label:def.label,value,group:groupName||'مشخصات فنی'});
    }
    return Array.from(found.values());
  }
  function parseLooseSpecs(text, groupName) {
    const definitions=[
      {label:'مدل و طرح',aliases:['نام مدل و طرح','مشخصه و مدل','مدل و طرح']},
      {label:'برند سازنده',aliases:['برند سازنده']},
      {label:'ارتفاع کل (سانتی‌متر)',aliases:['ارتفاع کل (سانتی‌متر)','ارتفاع (سانتی‌متر)','ارتفاع کل','ارتفاع']},
      {label:'قطر پایه (سانتی‌متر)',aliases:['قطر پایه (سانتی‌متر)','قطر پایه']},
      {label:'قطر کلاهک (سانتی‌متر)',aliases:['قطر کلاهک (سانتی‌متر)','قطر کلاهک']},
      {label:'جنس پایه',aliases:['جنس پایه و گوی‌ها','جنس پایه و گوی ها','جنس پایه']},
      {label:'جنس و طرح کلاهک',aliases:['جنس و طرح کلاهک (شید)','جنس کلاهک (شید)','جنس و طرح کلاهک','جنس کلاهک']},
      {label:'سیم و کلید',aliases:['سیم و کلید']},
      {label:'مکان‌های پیشنهادی استفاده',aliases:['مکان‌های پیشنهادی استفاده','مکان های پیشنهادی استفاده']}
    ];
    const source=String(text||''); const lower=source.toLowerCase(); const hits=[];
    definitions.forEach(def=>def.aliases.forEach(alias=>{
      let from=0; const needle=alias.toLowerCase();
      while(needle && from<lower.length){const at=lower.indexOf(needle,from);if(at<0)break;hits.push({start:at,end:at+needle.length,label:def.label,aliasLength:needle.length});from=at+needle.length;}
    }));
    hits.sort((a,b)=>a.start-b.start || b.aliasLength-a.aliasLength);
    const cleanHits=[];
    hits.forEach(hit=>{const overlaps=cleanHits.some(x=>hit.start<x.end&&hit.end>x.start);if(!overlaps)cleanHits.push(hit);});
    const result=[];const seen=new Set();
    cleanHits.forEach((hit,i)=>{
      if(seen.has(hit.label))return;
      const next=cleanHits.slice(i+1).find(x=>x.start>=hit.end);
      let rawValue=source.slice(hit.end,next?next.start:source.length);
      let value=deMarkdown(rawValue).replace(/^[\s:：|–—-]+|[\s|]+$/g,'').replace(/\s+/g,' ').trim();
      // A final table cell can be followed by a later paragraph; keep the first cell-like value only.
      value=value.split(/\s{2,}/)[0].trim();
      if(value.length>240)value=value.slice(0,240).trim();
      if(value){result.push({label:hit.label,value,group:groupName||'مشخصات فنی'});seen.add(hit.label);}
    });
    return result;
  }
  function mergeSpecItems(items) {
    const out=[]; const seen=new Set();
    items.forEach(item=>{const label=txt(item.label),value=txt(item.value),key=norm(label);if(!label||!value||seen.has(key))return;seen.add(key);out.push({label,value,group:item.group||'مشخصات فنی'});});
    return out;
  }
  function parsePairs(text, defaultGroup) {
    const items=[]; let group=defaultGroup||'مشخصات فنی';
    splitLines(text).forEach(raw=>{
      let line=raw.replace(/^\s*(?:(?:[-*•]+|\d+[.)]|[۰-۹٠-٩]+[.)])\s*)/,'').trim(); if(!line||/^\|?\s*:?-{2,}/.test(line))return;
      const clean=deMarkdown(line).replace(/^\|+|\|+$/g,'').trim();
      const cleanNorm=norm(clean);
      if(/جدول ویژگی ها برای تب|جدول مشخصات برای تب|اطلاعات محصول مشخصات فنی/.test(cleanNorm))return;
      let parts;
      if(clean.includes('|')) parts=clean.split('|').map(x=>x.trim()).filter(Boolean);
      else if(clean.includes('\t')) parts=clean.split('\t').map(x=>x.trim()).filter(Boolean);
      else {
        const colon=clean.match(/^(.{2,50}?)\s*[:：]\s*(.{2,})$/);
        if(colon) parts=[colon[1],colon[2]];
      }
      if(parts&&parts.length>=2){
        // Skip common table headings and separator rows.
        const key=norm(parts[0]);
        if(/^(نام ویژگی|ویژگی|مشخصه|نام|عنوان)$/.test(key) && /مقدار|توضیحات|مشخصه/.test(norm(parts[1])))return;
        // Many copied spreadsheet rows collapse multiple key/value pairs into one tab/piped row.
        if(parts.length>2){ for(let i=0;i+1<parts.length;i+=2){ const a=parts[i],b=parts[i+1]; if(a&&b&&!/^(ویژگی|نام ویژگی|مشخصه)$/.test(norm(a)))items.push({label:a,value:b,group}); } }
        else if(parts[0]&&parts[1]) items.push({label:parts[0],value:parts[1],group});
      } else if(!/[.!؟?]$/.test(clean) && clean.length<65 && !/^(جدول|پیش از|مشخصات فنی|ویژگی های وردپرس|ویژگی های مهم)/.test(norm(clean))) {
        // A standalone short title before a table is treated as the group title.
        if(items.length===0) group=clean;
      }
    });
    return {group,items};
  }
  function parseNumbered(input) {
    const out=blank();
    const sections=parseHeadingSections(input);
    if(!sections.length) return null;
    const titleSec=sectionBy(sections,/تایتل اصلی|عنوان اصلی|نام محصول|عنوان محصول/);
    out.title=cleanLine(splitLines(titleSec)[0]||'');
    const plainInput=readableSource(input);
    if(!out.title){const titleMatch=plainInput.match(/(?:^|\n)\s*(?:[0-9۰-۹٠-٩]{1,2}[.)،-]\s*)?(?:تایتل اصلی محصول|عنوان اصلی محصول|نام محصول)(?:\s|[:：(]|$)[^\n]*\n\s*([^\n]+)/i);if(titleMatch)out.title=cleanLine(titleMatch[1]);}
    let desc=sectionBy(sections,/توضیحات جامع|توضیحات محصول|product description/);
    let descriptionTable='';
    const tableMatch=desc.match(/جدول\s+(?:مشخصات\s+فنی|مشخصات|ویژگی(?:های|\s+های)?\s+فنی)[^\n]*/i);
    if(tableMatch){
      const tableStart=tableMatch.index;
      const tail=desc.slice(tableStart);
      const stop=tail.search(/نقد و بررسی تخصصی|بررسی تخصصی|مزایای خرید|سوالات متداول|جمع.?بندی|نتیجه.?گیری/i);
      const tableEnd=stop>=0?tableStart+stop:desc.length;
      descriptionTable=desc.slice(tableStart,tableEnd);
      desc=desc.slice(0,tableStart)+(stop>=0?desc.slice(tableEnd):'');
    }
    const faqHeading=desc.search(/سوالات متداول(?: خریداران)?/i);
    if(faqHeading>=0){
      const after=desc.slice(faqHeading);
      const end=after.search(/جمع.?بندی|خلاصه و خرید|نتیجه.?گیری/i);
      const faqBlock=end>=0?after.slice(0,end):after;
      out.faqs=parseFaqs(faqBlock);
      if(out.faqs.length) desc=desc.slice(0,faqHeading)+(end>=0?after.slice(end):'');
    }
    desc=desc.replace(/(?:توضیحات محصولم اینجا ست|توضیحات محصولم اینجاست)\s*$/,'');
    out.description=desc.trim();
    const cat=sectionBy(sections,/دسته.?بندی محصول|دسته محصول/);
    const categoryLines=splitLines(cat);
    out.categories=categoryLines.map(line=>{ const codes=Array.from(line.matchAll(/`([^`]+)`/g)).map(m=>m[1]); let x=codes.length?codes.join(' > '):cleanLine(line); const colon=x.indexOf(':'); if(colon>=0 && !x.includes('http')) x=x.slice(colon+1).trim(); return x.replace(/\s*&gt;\s*/gi,' > ').replace(/\s*>\s*/g,' > '); }).filter(Boolean);
    if(!out.categories.length){const categoryLine=plainInput.split('\n').find(line=>/دسته اصلی|دسته.?بندی محصول/i.test(norm(line)));if(categoryLine){const codes=Array.from(categoryLine.matchAll(/`([^`]+)`/g)).map(m=>m[1]);let value=codes.length?codes.join(' > '):categoryLine.replace(/^.*?:/,'').trim();value=value.replace(/&gt;/gi,'>').replace(/\s*>\s*/g,' > ');if(value)out.categories.push(cleanLine(value));}}
    const specsText=sectionBy(sections,/جدول ویژگی|جدول مشخصات|ویژگی.?ها برای تب|مشخصات فنی/);
    const tableItems=[
      ...parseBoldSpecTable(descriptionTable,'مشخصات فنی'),...parseLooseSpecs(descriptionTable,'مشخصات فنی'),...parsePairs(descriptionTable,'مشخصات فنی').items,
      ...parseBoldSpecTable(specsText,'مشخصات فنی'),...parseLooseSpecs(specsText,'مشخصات فنی'),...parsePairs(specsText,'مشخصات فنی').items
    ];
    const shortText=sectionBy(sections,/توضیحات کوتاه|short description/);
    const shortPairItems=parsePairs(shortText,'مشخصات فنی').items.filter(item=>/ابعاد|اندازه|سایز|ارتفاع|طول|عرض|عمق|قطر|وزن|گنجایش|ظرفیت|حجم|جنس|متریال|رنگ|مدل|تعداد|توان|ولتاژ|برند|سازنده|dimensions?|size|height|width|length|depth|diameter|weight|capacity|volume|material|color|model|quantity|watt|voltage/i.test(item.label));
    const shortSpecItems=[...parseBoldSpecTable(shortText,'مشخصات فنی'),...parseLooseSpecs(shortText,'مشخصات فنی'),...shortPairItems];
    const parsedSpecItems=mergeSpecItems([...tableItems,...shortSpecItems]);
    if(parsedSpecItems.length)out.specs=[{group:'مشخصات فنی',items:parsedSpecItems}];
    const attrText=sectionBy(sections,/ویژگی.?های مهم|ویژگی.?های وردپرس|حداکثر\s*4/);
    const attrParsed=parsePairs(attrText,''); out.attributes=attrParsed.items;
    out.short_description=shortText.trim();
    const tagsText=sectionBy(sections,/برچسب.?های محصول|برچسب.?ها\s*\(tags\)/);
    out.tags=tagsText.split(/[،,؛\n]+/).map(cleanLine).filter(Boolean);
    const seoText=sectionBy(sections,/تنظیمات افزونه rank math|rank math pro|سئو/);
    const seoLines=splitLines(seoText).map(x=>x.replace(/^\s*[-*•]+\s*/,''));
    const cleanSeoValue=(value)=>deMarkdown(value).replace(/\s*[-–—]{2,}\s*$/,'').trim();
    const getSeo=(rx)=>{const l=seoLines.find(x=>rx.test(norm(x)));return l?cleanSeoValue(l.split(/[:：]/).slice(1).join(':')):'';};
    const primary=getSeo(/کلمه کلیدی اصلی|focus keyword/); if(primary)out.keywords.push(primary);
    const secondary=getSeo(/کلمات کلیدی فرعی|کلمه.?های کلیدی فرعی|secondary/); if(secondary)out.keywords.push(...secondary.split(/[،,؛]+/).map(x=>x.replace(/`/g,'').trim()).filter(Boolean));
    out.seo.title=getSeo(/title|عنوان سئو|عنوان نتیجه/);
    out.seo.permalink=englishSlug(getSeo(/permalink|slug|پیوند یکتا/));
    out.seo.description=getSeo(/description|توضیحات متا|توضیح متا/);
    out.seo.breadcrumb=getSeo(/breadcrumb|عنوان مسیر راهنما/);
    if(!out.seo.breadcrumb){
      const line=splitLines(plainInput).find(x=>/breadcrumb|عنوان مسیر راهنما/i.test(norm(x)));
      const match=line&&line.match(/(?:breadcrumb(?:\s+title)?|عنوان مسیر راهنما)[^:：]*[:：]\s*([\s\S]*)/i);
      if(match)out.seo.breadcrumb=cleanSeoValue(match[1]);
    }
    const faqSection=sectionBy(sections,/سوالات متداول محصول|سوالات متداول خریداران/); if(faqSection)out.faqs=parseFaqs(faqSection);
    if(!out.faqs.length){const faqStart=plainInput.search(/سوالات متداول(?: خریداران)?/i);if(faqStart>=0){let faqBlock=plainInput.slice(faqStart);const end=faqBlock.search(/جمع.?بندی|نتیجه.?گیری|دسته.?بندی محصول/i);if(end>=0)faqBlock=faqBlock.slice(0,end);out.faqs=parseFaqs(faqBlock);}}
    if(out.faqs.length){const localFaq=desc.search(/سوالات متداول(?: خریداران)?/i);if(localFaq>=0){const rest=desc.slice(localFaq);const end=rest.search(/جمع.?بندی|خلاصه و خرید|نتیجه.?گیری/i);desc=desc.slice(0,localFaq)+(end>=0?rest.slice(end):'');}}
    const altText=sectionBy(sections,/متن جایگزین تصاویر|alt text/);
    out.image_alts=splitLines(altText).map(line=>{const code=Array.from(line.matchAll(/`([^`]+)`/g)).map(m=>m[1]);if(code.length)return deMarkdown(code[code.length-1]).trim();let x=cleanLine(line);x=x.replace(/^تصویر\s*[0-9۰-۹٠-٩]+\s*\([^)]*\)\s*[:：-]?\s*/i,'').replace(/^alt\s*text\s*[:：-]?\s*/i,'');return x;}).filter(Boolean);
    const brandSection=sectionBy(sections,/برند(?: محصول| سازنده)?\s*$/); if(brandSection)out.brand=cleanLine(splitLines(brandSection)[0]||'');
    return out;
  }
  function parseJson(raw) {
    let data=JSON.parse(raw); if(data&&data.product&&typeof data.product==='object')data=data.product;
    const o=blank();
    const get=(...keys)=>{for(const k of keys){if(data[k]!=null)return data[k];}return '';};
    o.title=txt(get('title','product_title','نام محصول','عنوان محصول'));
    o.description=txt(get('description','product_description','توضیحات جامع محصول'));
    o.short_description=txt(get('short_description','shortDescription','توضیحات کوتاه'));
    const cats=get('categories','category','دسته‌بندی');o.categories=Array.isArray(cats)?cats.map(x=>typeof x==='string'?x:(x.path||x.name||'')).filter(Boolean):(cats?[String(cats)]:[]);
    o.brand=typeof get('brand','برند')==='string'?get('brand','برند'):'';
    const tags=get('tags','برچسب‌ها');o.tags=Array.isArray(tags)?tags.map(String):String(tags||'').split(/[،,\n]+/).map(x=>x.trim()).filter(Boolean);
    const specs=get('specs','specifications','مشخصات فنی');
    if(Array.isArray(specs)){o.specs=specs.map(g=>({group:txt(g.group||g.title||'مشخصات فنی'),items:Array.isArray(g.items)?g.items.map(i=>({label:txt(i.label||i.name),value:txt(i.value)})).filter(i=>i.label&&i.value):[]})).filter(g=>g.items.length);}
    else if(specs&&typeof specs==='object'){o.specs=Object.keys(specs).map(g=>({group:g,items:Object.entries(specs[g]||{}).map(([label,value])=>({label,value:String(value)}))}));}
    const attrs=get('attributes','key_features','ویژگی‌های مهم');o.attributes=Array.isArray(attrs)?attrs.map(i=>typeof i==='string'?parseAttributeLine(i):({name:txt(i.name||i.label),value:txt(i.value)})).filter(i=>i.name&&i.value):[];
    const faqs=get('faqs','faq','سوالات متداول');o.faqs=Array.isArray(faqs)?faqs.map(i=>({question:txt(i.question||i.q),answer:txt(i.answer||i.a)})).filter(i=>i.question&&i.answer):[];
    const seo=get('seo','rank_math')||{};o.seo={title:txt(seo.title||get('seo_title')),permalink:englishSlug(seo.permalink||seo.slug||get('permalink','slug','پیوند یکتا')),description:txt(seo.description||seo.meta_description||get('meta_description')),breadcrumb:txt(seo.breadcrumb||seo.breadcrumb_title)};
    const kws=seo.keywords||get('keywords','focus_keywords');o.keywords=Array.isArray(kws)?kws.map(String):String(kws||'').split(/[،,\n]+/).map(x=>x.trim()).filter(Boolean);
    const alts=get('image_alts','alt_texts');o.image_alts=Array.isArray(alts)?alts.map(String):[];
    return o;
  }
  function parseAttributeLine(line){const p=String(line).split(/[|:：]/);return{name:txt(p.shift()),value:txt(p.join(' | '))};}
  function parseFaqLine(line){const i=String(line).indexOf('|');return i<0?{question:'',answer:''}:{question:txt(line.slice(0,i)),answer:txt(line.slice(i+1))};}
  function parseInput(raw) {
    const s=String(raw||'').trim(); if(!s)throw new Error('empty');
    if(s.startsWith('{'))return parseJson(s);
    const p=parseNumbered(s); if(!p)throw new Error('unparsed');
    if(!p.brand){
      // Infer a brand only when its exact existing taxonomy name occurs in the product title.
      const brandLabels=Array.from(document.querySelectorAll('#product_brandchecklist label')).map(l=>l.textContent.replace(/Make Term Primary/gi,'').trim()).filter(Boolean);
      const titleNorm=norm(p.title); const matches=brandLabels.filter(b=>titleNorm.includes(norm(b)));
      if(matches.length===1)p.brand=matches[0];
    }
    return p;
  }
  function closestTerm(checkboxes,wanted){
    const target=norm(wanted).split(' ').filter(x=>x&&x!=='و');let best=null;
    for(const cb of checkboxes){const li=cb.closest('li'),label=li?li.querySelector('label'):null;const name=label?label.textContent.replace(/Make Term Primary/gi,'').trim():'';const words=norm(name).split(' ').filter(x=>x&&x!=='و');const overlap=target.filter(x=>words.includes(x)).length;const score=overlap/Math.max(1,new Set(target.concat(words)).size);if(!best||score>best.score)best={name,score};}
    return best&&best.score>=0.45?best.name:'';
  }
  function updateSocialPreview(){
    const title=$id('jpi-social-preview-title'),description=$id('jpi-social-preview-description'),image=$id('jpi-social-preview-image'),choice=$id('jpi-social-use-featured-image');
    if(title)title.textContent=String($('#jpi-social-title').val()||'');
    if(description)description.textContent=String($('#jpi-social-description').val()||'');
    const imageUrl=choice&&choice.checked?String(JLuxeProductImport.featuredImageUrl||''):'';
    if(image){if(imageUrl){image.src=imageUrl;image.style.display='block';}else{image.removeAttribute('src');image.style.display='none';}}
  }
  $(document).on('input change','#jpi-social-title,#jpi-social-description,#jpi-social-use-featured-image',updateSocialPreview);

  function fillPreview(data) {
    parsed=data;
    const slugConsent=$id('jpi-apply-permalink');if(slugConsent)slugConsent.checked=false;
    const mediaConsent=$id('jpi-apply-alts');if(mediaConsent)mediaConsent.checked=false;
    const set=(id,v)=>{const el=$id(id);if(!el)return;const value=v||'';el.value=value;if(el.tagName==='TEXTAREA'){el.textContent=value;el.value=value;}else el.setAttribute('value',value);};
    set('jpi-title',data.title);set('jpi-description',data.description);set('jpi-short-description',data.short_description);
    set('jpi-categories',data.categories.join('\n'));set('jpi-brand',data.brand);set('jpi-tags',data.tags.join('\n'));
    set('jpi-specs',data.specs.flatMap(g=>[g.group,...g.items.map(i=>i.label+' | '+i.value),'']).join('\n').trim());
    set('jpi-attributes',data.attributes.map(i=>i.name+' | '+i.value).join('\n'));
    set('jpi-faqs',data.faqs.map(i=>i.question+' | '+i.answer).join('\n'));
    set('jpi-keywords',data.keywords.join('\n'));set('jpi-seo-title',data.seo.title);set('jpi-seo-permalink',data.seo.permalink||'');set('jpi-seo-description',data.seo.description);set('jpi-breadcrumb',data.seo.breadcrumb);set('jpi-alts',data.image_alts.join('\n'));
    set('jpi-social-title',JLuxeProductImport.currentSocialTitle||data.seo.title||data.title);set('jpi-social-description',JLuxeProductImport.currentSocialDescription||data.seo.description||data.short_description||'');const socialImageChoice=$id('jpi-social-use-featured-image');if(socialImageChoice){socialImageChoice.checked=false;socialImageChoice.disabled=!JLuxeProductImport.featuredImageUrl;}updateSocialPreview();
    const researchPanel=$id('jpi-research-panel'), insights=String(data.research_insights||'');set('jpi-research-insights',insights);
    const queries=Array.isArray(data.research_queries)?data.research_queries:[], sources=Array.isArray(data.research_sources)?data.research_sources:[];
    const queryWrap=$id('jpi-research-queries-wrap'), queryList=$id('jpi-research-queries');if(queryList){queryList.replaceChildren();queries.forEach(q=>{const li=document.createElement('li');li.textContent=String(q||'');queryList.appendChild(li);});}if(queryWrap)queryWrap.hidden=!queries.length;
    const sourceWrap=$id('jpi-research-sources-wrap'), sourceList=$id('jpi-research-sources');if(sourceList){sourceList.replaceChildren();sources.forEach(source=>{try{const u=new URL(String(source.url||''),window.location.href);if(u.protocol!=='https:')return;const li=document.createElement('li'),a=document.createElement('a');a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';a.textContent=String(source.title||u.href)+(source.reviewed?' — صفحه برای بررسی واکشی شد':' — نتیجهٔ جست‌وجو');li.appendChild(a);sourceList.appendChild(li);}catch(e){}});}if(sourceWrap)sourceWrap.hidden=!sourceList||!sourceList.children.length;
    if(researchPanel)researchPanel.hidden=!(insights.trim()||queries.length||sources.length);
    const mediaPlan=String(data.media_plan||'').trim();set('jpi-media-plan',mediaPlan);const mediaPanel=$id('jpi-media-plan-panel');if(mediaPanel)mediaPanel.hidden=!mediaPlan;
    const warns=Array.isArray(data.ai_warnings)?data.ai_warnings.slice():[];
    if(data.publish_ready===false){const blockers=Array.isArray(data.publish_blockers)?data.publish_blockers:[];warns.push('انتشار خودکار غیرفعال است؛ پیش از هر ذخیره یا انتشار، ادعاها و مشخصات را با منبع محصول بررسی کن.'+(blockers.length?' موارد نیازمند بررسی: '+blockers.join('؛ '):''));}
    if(!data.title)warns.push('عنوان محصول تشخیص داده نشد.');
    if(data.title&&!data.seo.permalink)warns.push('Slug انگلیسی از عنوان ساخته نشد؛ برای ترجمهٔ معنایی، «تحلیل با هوش مصنوعی» را با تیک رضایت اجرا کن یا پیوند یکتا را در پیش‌نمایش دستی به انگلیسی وارد کن.');
    if(!data.description)warns.push('توضیحات کامل تشخیص داده نشد.');
    if(!data.categories.length)warns.push('دسته محصول تشخیص داده نشد.');
    if(data.categories.some(c=>!c.includes('>')))warns.push('مسیر دسته‌ها را بررسی کن؛ بهتر است والد و فرزند با «>» جدا شوند.');
    const catChecks=document.querySelectorAll('#product_catchecklist input[type=checkbox][name="tax_input[product_cat][]"]');
    data.categories.forEach(path=>path.split(/\s*>\s*/).map(x=>x.trim()).filter(Boolean).forEach(term=>{if(!matchTerm(catChecks,term)){const suggestion=closestTerm(catChecks,term);warns.push('دستهٔ «'+term+'» دقیقاً در سایت پیدا نشد.'+(suggestion?' نزدیک‌ترین نام موجود «'+suggestion+'» است؛ اگر درست است مسیر را در پیش‌نمایش با همین نام اصلاح کن.':''));}}));
    if(!data.specs.length)warns.push('مشخصات فنی تشخیص داده نشدند یا جدول نیاز به اصلاح دستی دارد.');
    const robotsControls=Array.from(document.querySelectorAll('input,select,[role="checkbox"]'));
    const noindexEnabled=robotsControls.some(el=>{const identity=[el.id,el.name,el.value,el.getAttribute&&el.getAttribute('aria-label')].join(' ');return /noindex/i.test(identity)&&(el.type==='checkbox'||el.getAttribute&&el.getAttribute('role')==='checkbox'?!!el.checked:(el.tagName==='SELECT'?/noindex/i.test(el.value):false));});
    if(noindexEnabled)warns.push('تنظیم Noindex در Rank Math برای این محصول فعال به‌نظر می‌رسد؛ افزونهٔ ورود آن را تغییر نمی‌دهد. پیش از ذخیره، تنظیم ایندکس را جداگانه بررسی کن.');
    if(!data.faqs.length && /سوالات متداول/.test($source.val()))warns.push('تیتر FAQ پیدا شد اما زوج سوال/پاسخ به‌صورت مطمئن جدا نشد؛ متن FAQ را در پیش‌نمایش وارد کن.');
    $warnings.html(warns.map(w=>'<div class="jpi-warning">'+escapeHtml(w)+'</div>').join('') || '<div class="jpi-ok">ساختار کلی تشخیص داده شد؛ قبل از اعمال همهٔ فیلدها را بازبینی کن.</div>');
    const specCount=data.specs.reduce((n,g)=>n+g.items.length,0);
    const status='تحلیل v'+(JLuxeProductImport.version||'?')+' انجام شد | عنوان: '+(data.title?'✓':'—')+' | دسته: '+data.categories.length+' | مشخصات: '+specCount+' | FAQ: '+data.faqs.length+' | ویژگی ووکامرس: '+data.attributes.length;
    $preview.prop('hidden',false);$('#jluxe-import-status').text(status);
  }
  function escapeHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
  function lines(s){return String(s||'').split('\n').map(x=>x.trim()).filter(Boolean);}
  function parseGroupSpecs(text){
    const result=[];let current=null;
    lines(text).forEach(line=>{
      const parts=line.split('|').map(x=>x.trim());
      if(parts.length>=2){if(!current){current={group:'مشخصات فنی',items:[]};result.push(current);}current.items.push({label:parts[0],value:parts.slice(1).join(' | '),group:current.group});}
      else {current={group:line,items:[]};result.push(current);}
    });
    return result.filter(g=>g.items.length);
  }
  function syncAppliedPermalink(value){
    const field=$id('jluxe-import-payload');
    if(!field||!field.value)return;
    try{
      const payload=JSON.parse(field.value);
      if(!payload.apply_permalink)return;
      payload.seo=payload.seo||{};
      payload.seo.permalink=englishSlug(value);
      field.value=JSON.stringify(payload);
    }catch(e){}
  }
  $(document).on('input change','#jpi-seo-permalink,#rank-math-editor-permalink',function(){syncAppliedPermalink(this.value);});
  $(document).on('change','#jpi-apply-permalink',async function(){
    const allowed=this.checked;
    const field=$id('jluxe-import-payload');
    if(field&&field.value){
      try{
        const payload=JSON.parse(field.value);
        payload.apply_permalink=allowed?1:0;
        if(allowed){payload.seo=payload.seo||{};payload.seo.permalink=englishSlug($('#jpi-seo-permalink').val()||payload.seo.permalink||'');}
        field.value=JSON.stringify(payload);
      }catch(e){}
    }
    const slug=allowed?englishSlug($('#jpi-seo-permalink').val()):String(JLuxeProductImport.currentSlug||'');
    if(slug){const warnings=[];await applyRankMath({title:'',permalink:slug,description:'',breadcrumb:''},[],warnings);if(warnings.length)$warnings.append(warnings.map(w=>'<div class="jpi-warning">'+escapeHtml(w)+'</div>').join(''));}
  });

  function readPreview() {
    return {title:txt($('#jpi-title').val()),description:txt($('#jpi-description').val()),short_description:txt($('#jpi-short-description').val()),categories:lines($('#jpi-categories').val()),brand:txt($('#jpi-brand').val()),tags:lines($('#jpi-tags').val()),specs:parseGroupSpecs($('#jpi-specs').val()),attributes:lines($('#jpi-attributes').val()).map(parseAttributeLine).filter(i=>i.name&&i.value),faqs:lines($('#jpi-faqs').val()).map(parseFaqLine).filter(i=>i.question&&i.answer),keywords:lines($('#jpi-keywords').val()),seo:{title:txt($('#jpi-seo-title').val()),permalink:englishSlug($('#jpi-seo-permalink').val()),description:txt($('#jpi-seo-description').val()),breadcrumb:txt($('#jpi-breadcrumb').val())},social:{title:txt($('#jpi-social-title').val()),description:txt($('#jpi-social-description').val()),use_featured_image:$('#jpi-social-use-featured-image').is(':checked')?1:0},apply_permalink:$('#jpi-apply-permalink').is(':checked')?1:0,image_alts:lines($('#jpi-alts').val()),apply_image_alts:$('#jpi-apply-alts').is(':checked')?1:0,media_plan:txt($('#jpi-media-plan').val())};
  }
  function setValue(el,value){if(!el)return;el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
  function setEditor(id,value){
    const html=toHtml(value);const editor=window.tinymce&&tinymce.get(id);
    if(editor){editor.setContent(html);editor.save();}
    const ta=$id(id);if(ta){ta.value=html;ta.dispatchEvent(new Event('input',{bubbles:true}));ta.dispatchEvent(new Event('change',{bubbles:true}));}
  }
  function matchTerm(checkboxes,wanted){
    const target=norm(wanted);let exact=null;
    for(const cb of checkboxes){const li=cb.closest('li');const label=li?li.querySelector('label'):null;const name=label?label.textContent.replace(/Make Term Primary/gi,'').trim():'';if(norm(name)===target){exact={cb,name};break;}}
    return exact;
  }
  function applyCategories(categories,warns){
    const list=Array.from(document.querySelectorAll('#product_catchecklist input[type=checkbox][name="tax_input[product_cat][]"]'));
    categories.forEach(path=>{
      const parts=path.split(/\s*>\s*/).map(x=>x.trim()).filter(Boolean);
      const records=list.map(cb=>{const li=cb.closest('li'),label=li?li.querySelector('label'):null;return{cb,li,name:label?label.textContent.replace(/Make Term Primary/gi,'').trim():''};});
      let matches=[];
      if(parts.length===1){const exact=records.filter(r=>norm(r.name)===norm(parts[0]));if(exact.length===1)matches=exact;}
      else {
        let current=records.filter(r=>norm(r.name)===norm(parts[0])&&r.li&&!(r.li.parentElement&&r.li.parentElement.closest('li')));
        for(let i=1;i<parts.length&&current.length;i++){
          const next=records.filter(r=>norm(r.name)===norm(parts[i])&&r.li&&current.some(parent=>r.li.parentElement&&r.li.parentElement.closest('li')===parent.li));
          current=next.length===1?next:[];
        }
        if(current.length)matches=[...records.filter(r=>{const chain=[];let li=r.li;while(li){chain.unshift(li);li=li.parentElement&&li.parentElement.closest('li');}return chain.length===parts.length&&chain.every((item,index)=>norm(records.find(x=>x.li===item)?.name||'')===norm(parts[index]));})];
      }
      if(matches.length===parts.length){
        matches.forEach((m,index)=>{m.cb.checked=true;m.cb.dispatchEvent(new Event('change',{bubbles:true}));if(index===matches.length-1){const primary=m.cb.closest('li')?.querySelector('input.rank-math-make-primary');if(primary){primary.checked=true;primary.dispatchEvent(new Event('change',{bubbles:true}));}}});
      } else warns.push('دستهٔ «'+path+'» با همین مسیر و ساختار والد/فرزند دقیق پیدا نشد؛ هیچ بخشی از این مسیر انتخاب نشد. مسیر را در پیش‌نمایش اصلاح یا در فرم دستی انتخاب کن.');
    });
  }
  function applyBrand(brand,warns){
    if(!brand)return;const list=document.querySelectorAll('#product_brandchecklist input[type=checkbox][name="tax_input[product_brand][]"]');const m=matchTerm(list,brand);
    if(m){m.cb.checked=true;m.cb.dispatchEvent(new Event('change',{bubbles:true}));}else warns.push('برند «'+brand+'» در فهرست سایت تطبیق دقیق نداشت؛ خودکار ایجاد نشد.');
  }
  async function applyTags(tags){
    const input=$id('new-tag-product_tag'),button=document.querySelector('#tagsdiv-product_tag .tagadd');
    if(!input||!button)return;
    for(const tag of tags){if(tag){setValue(input,tag);button.click();await new Promise(resolve=>setTimeout(resolve,350));}}
  }
  function specTitleFields(){return Array.from(document.querySelectorAll('input[name^="jluxe_product_specs["][name$="[title]"]'));}
  function specGroupIndex(field){const m=String(field&&field.name||'').match(/^jluxe_product_specs\[(\d+)\]\[title\]$/);return m?Number(m[1]):-1;}
  function specRowPairs(index){
    const prefix='jluxe_product_specs['+index+']';
    const fields=Array.from(document.querySelectorAll('[name^="jluxe_product_specs["]')).filter(el=>String(el.name||'').startsWith(prefix+'[')&&el.name!==prefix+'[title]'&&el.type!=='hidden');
    const rows=new Map();
    fields.forEach(el=>{
      const name=String(el.name||'');
      let m=name.match(/\[(?:items|rows|specs|features|fields)\]\[(\d+)\]\[([^\]]+)\]$/i);
      if(!m)m=name.match(/\[(\d+)\]\[([^\]]+)\]$/);
      if(!m)return;
      const row=Number(m[1]),key=m[2].toLowerCase();if(!rows.has(row))rows.set(row,{});
      if(/^(?:label|name|key|feature|attribute|title)$/.test(key))rows.get(row).label=el;
      if(/^(?:value|description|content|detail|text)$/.test(key))rows.get(row).value=el;
    });
    let pairs=Array.from(rows.entries()).sort((a,b)=>a[0]-b[0]).map(([,r])=>r).filter(r=>r.label&&r.value);
    if(pairs.length)return pairs;
    const containers=Array.from(document.querySelectorAll('tr,.jluxe-spec-row,.jluxe-product-spec-row,[data-spec-row],[data-jluxe-spec-row]'));
    pairs=containers.map(row=>Array.from(row.querySelectorAll('input:not([type=hidden]),textarea')).filter(el=>String(el.name||'').startsWith(prefix+'['))).filter(fields=>fields.length>=2).map(fields=>({label:fields[0],value:fields[1]}));
    if(pairs.length)return pairs;
    const loose=fields.filter(el=>!/(?:remove|delete|add)/i.test(el.name));
    for(let i=0;i+1<loose.length;i+=2)pairs.push({label:loose[i],value:loose[i+1]});
    return pairs;
  }
  function specActionButton(title,kind){
    const selectors=kind==='group'?'[data-jluxe-spec-add-group],[data-add-spec-group],.jluxe-add-spec-group,.add-spec-group':'[data-jluxe-spec-add-row],[data-add-spec-row],.jluxe-add-spec-row,.add-spec-row';
    let direct=document.querySelector(selectors);if(direct)return direct;
    const re=kind==='group'?/(?:افزودن|اضافه|add).*(?:گروه|group)|(?:گروه|group).*(?:افزودن|اضافه|add)/i:/(?:افزودن|اضافه|add).*(?:ردیف|ویژگی|مشخصه|row|feature)|(?:ردیف|ویژگی|مشخصه|row|feature).*(?:افزودن|اضافه|add)/i;
    let node=title;
    for(let depth=0;node&&depth<7;depth++,node=node.parentElement){
      const button=Array.from(node.querySelectorAll('button,a.button,input[type=button]')).find(el=>re.test((el.textContent||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.className||'')));
      if(button)return button;
    }
    return Array.from(document.querySelectorAll('button,a.button,input[type=button]')).find(el=>re.test((el.textContent||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.className||'')))||null;
  }
  const waitMs=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  function isBrandFeatureName(value){return /برند|سازنده|brand|manufacturer/i.test(norm(value));}
  function isBrandFeatureValue(value,brand){const normalized=norm(value),selected=norm(brand);return !!selected&&normalized.includes(selected);}
  async function applyGroupedSpecs(groups,warns,brand){
    if(!groups.length)return '';
    let titles=specTitleFields();
    if(titles.length){
      while(titles.length<groups.length){const add=specActionButton(titles[titles.length-1],'group');if(!add)break;add.click();await waitMs(80);titles=specTitleFields();}
      const plans=[];
      for(let i=0;i<groups.length;i++){
        const title=titles.find(el=>specGroupIndex(el)===i)||titles[i];if(!title)break;
        const index=specGroupIndex(title);if(index<0)break;
        let pairs=specRowPairs(index);
        while(pairs.length<(groups[i].items||[]).length){const add=specActionButton(title,'row');if(!add)break;add.click();await waitMs(80);pairs=specRowPairs(index);}
        if(pairs.length<(groups[i].items||[]).length)break;
        plans.push({title,index,pairs});
      }
      if(plans.length===groups.length){
        plans.forEach((plan,i)=>{setValue(plan.title,groups[i].group||'مشخصات فنی');groups[i].items.forEach((item,row)=>{setValue(plan.pairs[row].label,item.label);setValue(plan.pairs[row].value,item.value);});for(let row=groups[i].items.length;row<plan.pairs.length;row++){const oldLabel=String(plan.pairs[row].label.value||''),oldValue=String(plan.pairs[row].value.value||'');if(brand&&isBrandFeatureName(oldLabel)&&isBrandFeatureValue(oldValue,brand)){setValue(plan.pairs[row].label,'');setValue(plan.pairs[row].value,'');}}});
        const fallback=$id('jluxe-product-spec-groups-input');if(fallback)setValue(fallback,'');
        return 'native';
      }
      warns.push('کادر jluxe_product_specs پیدا شد، اما ردیف‌های نام/مقدار برای همهٔ مشخصات شناسایی نشدند؛ پیش‌نمایش را بررسی کن.');
    }
    const field=$id('jluxe-product-spec-groups-input');
    if(!field){warns.push('فیلد مشخصات گروه‌بندی‌شده پیدا نشد؛ مشخصات در پیش‌نمایش ماندند.');return '';}
    const linesOut=[];groups.forEach(g=>{if(!g.items||!g.items.length)return;linesOut.push(g.group||'مشخصات فنی');g.items.forEach(item=>linesOut.push(item.label+' | '+item.value));linesOut.push('');});
    if(linesOut.length){setValue(field,linesOut.join('\n').trim());return 'plugin';}
    return '';
  }
  function applyFaqs(faqs,warns){
    if(!faqs.length)return;
    const root=$id('jluxe-faq-items');if(!root){warns.push('کادر FAQ اختصاصی پوسته پیدا نشد؛ سوالات در پیش‌نمایش ماندند و اعمال نشدند.');return;}
    const add=$id('jluxe-add-faq-item');if(!add){warns.push('دکمهٔ افزودن FAQ پوسته پیدا نشد؛ FAQهای قبلی دست‌نخورده ماندند.');return;}
    root.querySelectorAll('.jluxe-faq-item .jluxe-faq-remove-item').forEach(b=>b.click());
    faqs.forEach(f=>{add.click();const items=root.querySelectorAll('.jluxe-faq-item');const item=items[items.length-1];if(!item)return;const q=item.querySelector('input[name*="[question]"]'),a=item.querySelector('textarea[name*="[answer]"]');setValue(q,f.question);setValue(a,f.answer);});
  }
  function applyAttributes(attrs,warns){
    if(!attrs.length)return;
    const tab=document.querySelector('.attribute_tab a');if(tab)tab.click();
    const add=document.querySelector('.add_custom_attribute');
    attrs.forEach(attr=>{
      let row=null;
      document.querySelectorAll('#product_attributes .woocommerce_attribute').forEach(r=>{const n=r.querySelector('input.attribute_name');if(n&&norm(n.value)===norm(attr.name))row=r;});
      if(!row&&add){add.click();const rows=document.querySelectorAll('#product_attributes .woocommerce_attribute');row=rows[rows.length-1];}
      if(!row){warns.push('ویژگی ووکامرس «'+attr.name+'» از طریق رابط فعلی اضافه نشد.');return;}
      const name=row.querySelector('input.attribute_name'),values=row.querySelector('textarea.attribute_values, input.attribute_values');
      if(name)setValue(name,attr.name);if(values)setValue(values,attr.value);
      const visible=row.querySelector('input.attribute_visibility');if(visible){visible.checked=true;visible.dispatchEvent(new Event('change',{bubbles:true}));}
    });
    const save=document.querySelector('#product_attributes .save_attributes');if(save)save.click();
  }
  function setReactValue(el,value){
    if(!el)return false;
    const proto=el.tagName==='TEXTAREA'?window.HTMLTextAreaElement&&window.HTMLTextAreaElement.prototype:window.HTMLInputElement&&window.HTMLInputElement.prototype;
    const descriptor=proto&&Object.getOwnPropertyDescriptor(proto,'value');
    if(descriptor&&descriptor.set)descriptor.set.call(el,value);else el.value=value;
    el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;
  }
  function waitForElement(selector,timeout=3500){
    const existing=document.querySelector(selector);if(existing)return Promise.resolve(existing);
    return new Promise(resolve=>{let done=false;const finish=value=>{if(done)return;done=true;if(observer)observer.disconnect();clearTimeout(timer);resolve(value);};const observer=window.MutationObserver?new MutationObserver(()=>{const found=document.querySelector(selector);if(found)finish(found);}):null;if(observer)observer.observe(document.body,{childList:true,subtree:true});const timer=setTimeout(()=>finish(document.querySelector(selector)),timeout);});
  }
  function getRankMathKeywordEditor(){
    return document.querySelector('span.tagify__input[contenteditable="true"][data-placeholder*="Rank Math"]')||document.querySelector('span.tagify__input[contenteditable="true"][aria-label="Tags input field"]');
  }
  async function applyRankMathKeywords(keywords,warns){
    if(!keywords.length)return;
    const input=getRankMathKeywordEditor();if(!input){warns.push('کادر کلمات کلیدی Tagify در Rank Math پیدا نشد؛ کلمات در پیش‌نمایش/متادیتا باقی ماندند.');return;}
    const wrapper=input.closest('.tagify');
    const instance=(input.__tagify||input.tagify)||(wrapper&&(wrapper.__tagify||wrapper.tagify||Array.from(wrapper.parentElement?wrapper.parentElement.querySelectorAll('input'):[]).map(el=>el.__tagify||el.tagify).find(Boolean)));
    try{
      if(instance&&typeof instance.addTags==='function'){
        if(typeof instance.removeAllTags==='function')instance.removeAllTags();
        instance.addTags(keywords);return;
      }
      if(wrapper){wrapper.querySelectorAll('.tagify__tag__removeBtn,button[aria-label*="حذف"],button[title*="حذف"]').forEach(btn=>btn.click());}
      for(const keyword of keywords){
        input.focus();input.textContent=keyword;
        const evt=window.InputEvent?new InputEvent('input',{bubbles:true,inputType:'insertText',data:keyword}):new Event('input',{bubbles:true});input.dispatchEvent(evt);
        input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',which:13,keyCode:13,bubbles:true}));
        input.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',which:13,keyCode:13,bubbles:true}));
        await waitMs(80);
      }
      if(wrapper){const rendered=Array.from(wrapper.querySelectorAll('.tagify__tag-text')).map(el=>norm(el.textContent));if(!keywords.every(k=>rendered.includes(norm(k))))warns.push('همهٔ کلمات کلیدی در Tagify به‌صورت تگ تأیید نشدند؛ کادر Rank Math را قبل از ذخیره بررسی کن.');}
    }catch(e){warns.push('به‌روزرسانی دیداری کلمات کلیدی Rank Math ناموفق بود؛ متادیتا پس از ذخیره از سمت سرور ثبت می‌شود.');}
  }
  function findBreadcrumbInput(){
    const selector='input[id^="inspector-text-control-"],textarea[id^="inspector-text-control-"]';
    const direct=Array.from(document.querySelectorAll('.rank-math-breadcrumb-title input[id^="inspector-text-control-"],.rank-math-breadcrumb-title textarea[id^="inspector-text-control-"]'));
    const visibleDirect=direct.find(el=>isElementVisible(el)&&!el.disabled);
    if(visibleDirect)return visibleDirect;
    const panel=document.querySelector('[role="tabpanel"][aria-labelledby$="-advanced"], [role="tabpanel"][id$="-advanced-view"]');
    const scope=panel||document;
    const controls=Array.from(scope.querySelectorAll(selector));
    const target=norm('عنوان مسیر راهنما');
    for(const el of controls){
      const associated=Array.from(el.labels||[]).concat(el.closest('label')?[el.closest('label')]:[]);
      if(associated.some(label=>norm(label.textContent).includes(target)))return el;
      const labelledBy=(el.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>document.getElementById(id)).filter(Boolean);
      if(labelledBy.some(label=>norm(label.textContent).includes(target)))return el;
      if(norm(el.getAttribute('aria-label')||'').includes(target))return el;
      let node=el;
      for(let depth=0;node&&depth<14;depth++,node=node.parentElement){
        const labels=Array.from(node.querySelectorAll?node.querySelectorAll('label,.components-base-control__label'):[]);
        if(labels.some(label=>norm(label.textContent).includes(target)))return el;
        const related=Array.from(node.querySelectorAll?node.querySelectorAll(selector):[]);
        if(node!==el&&related.length===1&&norm(node.textContent||'').includes(target))return el;
      }
    }
    if(panel&&controls.length===1)return controls[0];
    return null;
  }
  function waitForBreadcrumbInput(timeout=5000){
    return new Promise(resolve=>{
      let done=false;
      const finish=input=>{if(done)return;done=true;clearInterval(poll);clearTimeout(timer);if(observer)observer.disconnect();resolve(input||null);};
      const check=()=>{const input=findBreadcrumbInput();if(input)finish(input);};
      const observer=window.MutationObserver?new window.MutationObserver(check):null;
      if(observer&&document.body)observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['id','aria-label','aria-labelledby']});
      const poll=setInterval(check,120);
      const timer=setTimeout(()=>finish(null),timeout);
      check();
    });
  }
  async function activateRankMathGeneral(){
    const tab=document.querySelector('button.rank-math-general-tab')||document.querySelector('button[role="tab"][aria-controls$="-general-view"]')||document.querySelector('button[id$="-general"][aria-controls$="-general-view"]');
    if(tab&&tab.getAttribute('aria-selected')!=='true'){tab.click();await waitMs(220);}
    else await waitMs(100);
  }
  async function activateRankMathAdvanced(){
    const selector='button.rank-math-advanced-tab,button[role="tab"][aria-controls$="-advanced-view"],button[id$="-advanced"][aria-controls$="-advanced-view"]';
    const tabs=Array.from(document.querySelectorAll(selector));
    const tab=tabs.find(isElementVisible)||tabs[0];
    if(tab&&tab.getAttribute('aria-selected')!=='true'){tab.click();await waitMs(300);}
    else await waitMs(180);
  }
  async function applyRankMathBreadcrumb(value,warns){
    if(!value)return;
    await activateRankMathAdvanced();
    const input=await waitForBreadcrumbInput(5000);
    if(input){input.focus();setReactValue(input,value);input.dispatchEvent(new Event('blur',{bubbles:true}));await waitMs(180);if(input.value!==value)setReactValue(input,value);}
    else warns.push('فیلد «عنوان مسیر راهنما» در تب پیشرفته Rank Math پیدا نشد؛ متادیتا از سمت سرور ذخیره می‌شود.');
  }
  async function applyRankMath(seo,keywords,warns){
    await activateRankMathGeneral();
    await applyRankMathKeywords(keywords,warns);
    const needsSnippet=!!(seo.title||seo.permalink||seo.description);
    const editButton=document.querySelector('button.rank-math-edit-snippet');
    let openedSnippetModal=false;
    let title=seo.title?document.getElementById('rank-math-editor-title'):null;
    if(needsSnippet&&!isElementVisible(title)&&editButton){editButton.click();openedSnippetModal=true;}
    if(seo.title&&!isElementVisible(title))title=await waitForVisibleElement('#rank-math-editor-title',4000);
    const permalink=seo.permalink?await waitForVisibleElement('#rank-math-editor-permalink',needsSnippet?1800:0):null;
    const description=seo.description?await waitForVisibleElement('#rank-math-editor-description',needsSnippet?1800:0):null;
    if(seo.title){if(title){setReactValue(title,seo.title);await waitMs(100);}else warns.push('فیلد عنوان Snippet در Rank Math باز نشد؛ عنوان سئو از مسیر متادیتای سمت سرور ذخیره می‌شود.');}
    if(seo.permalink){if(permalink){setReactValue(permalink,seo.permalink);await waitMs(100);}else warns.push('فیلد پیوند یکتای Snippet در Rank Math پیدا نشد؛ URL را دستی بررسی کن.');}
    if(seo.description){if(description){setReactValue(description,seo.description);await waitMs(100);}else warns.push('فیلد توضیح Snippet در Rank Math پیدا نشد؛ توضیح متا از مسیر متادیتای سمت سرور ذخیره می‌شود.');}
    // Breadcrumb lives in the sidebar Advanced panel, not the Snippet modal; close the modal before its final update.
    if((openedSnippetModal||seo.breadcrumb)&&!await closeRankMathSnippetEditor())warns.push('پنجرهٔ Snippet بسته نشد؛ فیلد مسیر راهنما ممکن است پشت پنجره باشد. آن را دستی بررسی کن.');
    await applyRankMathBreadcrumb(seo.breadcrumb,warns);
  }
  async function closeRankMathSnippetEditor(){
    const editor=document.querySelector('.components-modal__content .rank-math-tabs.rank-math-editor');
    const modal=editor&&editor.closest('.components-modal__content');
    if(!isElementVisible(modal))return true;
    const close=modal.querySelector('button[aria-label="بستن"],button[aria-label="Close"]');
    if(!close)return false;
    close.click();
    for(let i=0;i<35;i++){await waitMs(100);if(!isElementVisible(modal))return true;}
    return false;
  }
  function isElementVisible(el){
    if(!el||!el.isConnected||el.hidden)return false;
    const style=window.getComputedStyle?window.getComputedStyle(el):null;
    if(style&&(style.display==='none'||style.visibility==='hidden'||style.opacity==='0'))return false;
    return !el.getClientRects||el.getClientRects().length>0;
  }
  function waitForVisibleElement(selector,timeout=3000){
    return new Promise(resolve=>{
      const check=()=>{const el=document.querySelector(selector);return isElementVisible(el)?el:null;};
      const immediate=check();if(immediate)return resolve(immediate);
      const started=Date.now();const poll=setInterval(()=>{const el=check();if(el){clearInterval(poll);clearTimeout(timer);resolve(el);}else if(Date.now()-started>=timeout){clearInterval(poll);clearTimeout(timer);resolve(null);}},100);
      const timer=setTimeout(()=>{clearInterval(poll);resolve(check());},timeout);
    });
  }
  async function applyImageAlts(alts,warns){
    if(!alts.length)return;
    const selector='button.osn-pe-btn.osn-pe-alt[data-id]';
    let buttons=Array.from(document.querySelectorAll(selector));
    if(!buttons.length){await waitForElement(selector,1800);buttons=Array.from(document.querySelectorAll(selector));}
    const ids=Array.isArray(JLuxeProductImport.imageIds)?JLuxeProductImport.imageIds.map(String):[];
    let saved=0;
    for(let i=0;i<alts.length;i++){
      const id=ids[i]||'';
      const button=(id&&buttons.find(el=>String(el.dataset.id||'')===id))||buttons[i]||null;
      if(!button){warns.push('دکمهٔ ویرایش Alt برای تصویر شمارهٔ '+(i+1)+' پیدا نشد؛ مقدار تأییدشده از مسیر سمت سرور پس از ذخیره اعمال می‌شود.');continue;}
      button.click();
      const input=await waitForVisibleElement('#osn-pe-alt-input',3000);
      const card=input&&input.closest('.osn-pe-modal-card');
      const save=card&&card.querySelector('.osn-pe-alt-save')||document.querySelector('button.osn-pe-alt-save');
      if(!input||!save){warns.push('پنجرهٔ «ویرایش متن جایگزین تصویر» باز نشد؛ مقدار تصویر شمارهٔ '+(i+1)+' پس از ذخیره از سمت سرور اعمال می‌شود.');continue;}
      input.focus();setValue(input,alts[i]);input.dispatchEvent(new Event('input',{bubbles:true}));
      if(input.value!==alts[i]){warns.push('متن Alt تصویر شمارهٔ '+(i+1)+' در کادر قرار نگرفت؛ آن را دستی بررسی کن.');continue;}
      await waitMs(120);save.click();
      const closed=await new Promise(resolve=>{const started=Date.now();const poll=setInterval(()=>{if(!isElementVisible(input)){clearInterval(poll);clearTimeout(timer);resolve(true);}else if(Date.now()-started>=4500){clearInterval(poll);clearTimeout(timer);resolve(false);}},100);const timer=setTimeout(()=>{clearInterval(poll);resolve(!isElementVisible(input));},4500);});
      if(!closed){warns.push('پنجرهٔ Alt برای تصویر شمارهٔ '+(i+1)+' پس از ذخیره بسته نشد؛ ذخیرهٔ آن را بررسی کن و تصاویر بعدی را دستی انجام بده.');break;}
      saved++;
      await waitMs(180);
    }
    if(saved)$('#jluxe-import-status').text('Altهای تأییدشده در پنجرهٔ رسانه ذخیره شدند؛ در پایان محصول را هم ذخیره کن.');
  }

  async function applyAll(options={}){
    const automatic=!!options.automatic;
    const d=readPreview(),warnings=[];
    if(!automatic&&d.title)setValue($id('title'),d.title);
    if(d.description)setEditor('content',d.description);
    if(d.short_description)setEditor('excerpt',d.short_description);
    if(!automatic){applyCategories(d.categories,warnings);applyBrand(d.brand,warnings);await applyTags(d.tags);}
    else warnings.push('حالت خودکار فقط متن، مشخصات، ویژگی‌ها و متادیتای SEO را اعمال کرد؛ عنوان، دسته/برند/برچسب، slug و Alt رسانه‌ها تغییر نکردند.');
    const specsTarget=await applyGroupedSpecs(d.specs,warnings,d.brand);applyFaqs(d.faqs,warnings);applyAttributes(d.attributes,warnings);
    if(d.seo.title)setValue($id('jluxe-seo-title'),d.seo.title);
    if(d.seo.description)setValue($id('jluxe-seo-description'),d.seo.description);
    const seoForRankMath=Object.assign({},d.seo,{permalink:d.apply_permalink?d.seo.permalink:''});
    if(d.seo.permalink&&!d.apply_permalink)warnings.push('slug پیشنهادی فقط در پیش‌نمایش ماند؛ URL محصول تغییر نکرد، چون گزینهٔ رضایت صریح انتخاب نشده است.');
    await applyRankMath(seoForRankMath,d.keywords,warnings);
    if(!automatic&&d.apply_image_alts)await applyImageAlts(d.image_alts,warnings);
    else if(!automatic&&d.image_alts.length)warnings.push('Alt تصاویر وارد پیش‌نمایش شده‌اند، اما اعمال نشدند؛ برای تغییر صریح رسانه، تیک «اجازهٔ تغییر Alt فایل‌های رسانه‌ای» را بزن و دوباره اعمال کن.');
    const payload={seo:d.seo,social:automatic?{}:d.social,keywords:d.keywords,apply_permalink:automatic?false:d.apply_permalink,image_alts:automatic?[]:d.image_alts,apply_image_alts:automatic?false:d.apply_image_alts,specs_target:specsTarget,has_specs:d.specs.length?1:0};
    setValue($id('jluxe-import-payload'),JSON.stringify(payload));
    if(warnings.length){$warnings.append(warnings.map(w=>'<div class="jpi-warning">'+escapeHtml(w)+'</div>').join(''));}
    $('#jluxe-import-status').text(JLuxeProductImport.labels.applied);
    const target=$id('jluxe-product-import-assistant');if(target)target.scrollIntoView({behavior:'smooth',block:'start'});
  }

  window.JLuxeProductImportParser = Object.freeze({ parse: parseInput, sections: parseHeadingSections, toHtml });

  async function readAjaxJson(response,operation){
    const body=await response.text();
    try{
      const parsed=JSON.parse(body.replace(/^\uFEFF/,''));
      if(parsed&&typeof parsed==='object'&&Object.prototype.hasOwnProperty.call(parsed,'success'))return parsed;
      throw new Error('Unexpected WordPress AJAX response envelope.');
    }
    catch(parseError){
      const titleMatch=body.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const pageTitle=titleMatch?titleMatch[1].replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim().slice(0,100):'';
      let hint='ممکن است نشست ورود، فایروال/افزونهٔ امنیتی یا CDN درخواست admin-ajax را به صفحهٔ HTML هدایت کرده باشد.';
      if(response.status===401||response.status===403)hint='احتمالاً نشست ورود منقضی شده یا فایروال/افزونهٔ امنیتی درخواست admin-ajax را مسدود کرده است.';
      else if(response.status>=500)hint='احتمال خطای PHP یا محدودیت منابع سرور وجود دارد؛ گزارش خطای PHP/WordPress هاست را بررسی کنید.';
      throw new Error(operation+'؛ سرور به‌جای JSON پاسخ دیگری داد (HTTP '+response.status+(pageTitle?'، صفحهٔ «'+pageTitle+'»':'')+'). '+hint+' صفحهٔ مدیریت را تازه‌سازی کنید و اگر تکرار شد، همین کد وضعیت و عنوان صفحه را به مدیر هاست بدهید.');
    }
  }

  async function runContentDraft(button){
    const consent=$id('jpi-seo-draft-consent');
    const useImages=$id('jpi-content-use-images');
    const imageConsent=$id('jpi-content-image-consent');
    const mode=String($id('jpi-content-mode')&&$id('jpi-content-mode').value||'preview');
    const postStatus=String($id('post_status')&&$id('post_status').value||'draft');
    if(!consent||!consent.checked){window.alert('برای ارسال اطلاعات ذخیره‌شدهٔ محصول و یادداشت‌ها، ابتدا رضایت را تأیید کن.');return;}
    if(useImages&&useImages.checked&&(!imageConsent||!imageConsent.checked)){window.alert('برای ارسال عکس‌ها، رضایت جداگانهٔ تصویر را هم تأیید کن.');return;}
    if(mode==='publish'){window.alert('انتشار خودکار در این نسخه غیرفعال است. پیش‌نویس را بازبینی و سپس با کنترل‌های عادی وردپرس ذخیره کن.');return;}
    if(mode==='draft'&&postStatus==='publish'){window.alert('برای محصول منتشرشده، حالت «پرکردن فرم بدون ذخیره» را انتخاب کن و پس از بازبینی از دکمهٔ عادی «به‌روزرسانی» وردپرس استفاده کن.');return;}
    const productId=String($('#post_ID').val()||'').trim();
    if(!productId||productId==='0'){window.alert('برای ساخت پیش‌نویس از اطلاعات و تصاویر ذخیره‌شده، ابتدا محصول را با دکمهٔ معمول وردپرس ذخیره کن؛ افزونه خودش ذخیره نمی‌کند.');return;}
    const sellerNotes=String($id('jpi-seo-draft-notes').value||'').trim();
    const oldText=button.textContent;button.disabled=true;button.textContent='در حال ساخت پیش‌نویس کامل…';$('#jpi-content-draft-status').text('در حال ارسال داده‌های محصول'+(sellerNotes?' و یادداشت فروشنده ('+sellerNotes.length+' نویسه)':'')+(useImages&&useImages.checked?' و تصاویر منتخب':'')+' به ارائه‌دهندهٔ انتخاب‌شده…');
    try{
      const form=new URLSearchParams();form.set('action','jluxe_product_content_draft');form.set('nonce',JLuxeProductImport.nonce);form.set('product_id',productId);form.set('product_title',String($id('title').value||''));form.set('notes',sellerNotes);form.set('english_model',String($id('jpi-content-english-model').value||''));form.set('target_audience',String($id('jpi-content-target-audience').value||''));form.set('advantages',String($id('jpi-content-advantages').value||''));form.set('visual_notes',String($id('jpi-content-visual-notes').value||''));form.set('consent','1');
      const searchConsent=$id('jpi-content-web-research');if(searchConsent&&searchConsent.checked){form.set('use_web_research','1');form.set('web_consent','1');}
      if(useImages&&useImages.checked){form.set('use_images','1');form.set('image_consent','1');}
      const response=await fetch(JLuxeProductImport.ajaxUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:form.toString()});
      const result=await readAjaxJson(response,'ساخت پیش‌نویس کامل انجام نشد');
      if(!response.ok||!result.success)throw new Error(result&&result.data&&result.data.message?result.data.message:'ساخت پیش‌نویس کامل انجام نشد.');
      const data=result.data||{};
      fillPreview(data);
      $('#jpi-manual-source').prop('hidden',true);
      $('#jpi-manual-modal-title').text('بازبینی پیش‌نویس خودکار محتوا و SEO');
      openModal('jpi-manual-modal',$id('jpi-open-auto-modal'));
      const preview=$id('jluxe-import-preview');
      const modalBody=$id('jpi-manual-modal')&&$id('jpi-manual-modal').querySelector('.jpi-modal-body');
      if(preview&&modalBody)modalBody.scrollTo({top:preview.offsetTop,behavior:'smooth'});
      if(mode==='apply'||mode==='draft'){
        await applyAll({automatic:true});
        if(mode==='apply'){$('#jpi-content-draft-status').text('فیلدهای مجاز در فرم قرار گرفتند؛ هیچ تغییری ذخیره نشده و انتشار نشده است.');return;}
        const saveButton=$id('save-post');
        if(!saveButton){$('#jpi-content-draft-status').text('فیلدها اعمال شدند، اما دکمهٔ ذخیرهٔ امن پیدا نشد؛ محصول را دستی ذخیره کن.');return;}
        $('#jpi-content-draft-status').text('در حال ذخیرهٔ پیش‌نویس؛ منتشر نخواهد شد…');
        const productForm=$id('post');
        if(productForm&&typeof productForm.requestSubmit==='function')productForm.requestSubmit(saveButton);else saveButton.click();
        return;
      }
      $('#jpi-content-draft-status').text('پیش‌نویس کامل آمادهٔ بازبینی است؛ هیچ فیلدی هنوز اعمال یا ذخیره نشده.');
    }catch(error){$('#jpi-content-draft-status').text('');window.alert(error.message||'خطا هنگام ساخت محتوای محصول. اگر مدل تصویر را نپذیرفت، گزینهٔ تحلیل تصویر را خاموش کن یا مدل بینایی‌پذیر انتخاب کن.');}
    finally{button.disabled=false;button.textContent=oldText;}
  }

  async function runAiAnalysis(button){
    const consent=$id('jluxe-import-ai-consent');
    if(!consent||!consent.checked){window.alert('برای فرستادن متن به سرویس AI، ابتدا تیک رضایت را بزن.');return;}
    const source=String($source.val()||'').trim();
    if(!source){window.alert('ابتدا متن یا JSON محصول را وارد کن.');return;}
    if(source.length>40000){window.alert('متن ورودی خیلی طولانی است؛ آن را کوتاه‌تر کن (حداکثر ۴۰٬۰۰۰ نویسه).');return;}
    const oldText=button.textContent;button.disabled=true;button.textContent='در حال تحلیل…';$('#jluxe-import-status').text('در حال ارسال متن به ارائه‌دهندهٔ AI پوسته…');
    try{
      const form=new URLSearchParams();form.set('action','jluxe_product_import_ai');form.set('nonce',JLuxeProductImport.nonce);form.set('product_id',$('#post_ID').val()||'0');form.set('source',source);form.set('consent','1');
      const response=await fetch(JLuxeProductImport.ajaxUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:form.toString()});
      const result=await readAjaxJson(response,'تحلیل AI انجام نشد');
      if(!response.ok||!result.success)throw new Error(result&&result.data&&result.data.message?result.data.message:'تحلیل AI انجام نشد.');
      fillPreview(result.data);
    }catch(error){$preview.prop('hidden',true);$('#jluxe-import-status').text('');window.alert(error.message||'خطا در ارتباط با سرویس AI.');}
    finally{button.disabled=false;button.textContent=oldText;}
  }

  $('#jluxe-content-draft-generate').on('click',function(){runContentDraft(this);});
  $('#jpi-load-scheduled-preview').on('click',function(){
    try{const data=JSON.parse(String(this.dataset.preview||'{}'));if(!data||typeof data!=='object')throw new Error('پیش‌نمایش ذخیره‌شده معتبر نیست.');fillPreview(data);$('#jpi-manual-source').prop('hidden',true);$('#jpi-manual-modal-title').text('بازبینی پیش‌نمایش صف زمان‌بندی‌شده');openModal('jpi-manual-modal',this);}
    catch(error){window.alert(error.message||'خواندن پیش‌نمایش زمان‌بندی‌شده ناموفق بود.');}
  });
  $('#jluxe-import-ai-analyze').on('click',function(){runAiAnalysis(this);});
  $('#jluxe-import-analyze').on('click',function(){
    try{const data=parseInput($source.val());fillPreview(data);}
    catch(e){$preview.prop('hidden',true);window.alert(JLuxeProductImport.labels.parseError+'\n\nاگر متن بخش‌بندی‌شده است، تیترهای شماره‌دار مثل «۱. عنوان محصول» را نگه دار. برای ورودی JSON، مطمئن شو JSON معتبر است.');}
  });
  $('#jluxe-import-clear').on('click',function(){$source.val('');$preview.prop('hidden',true);$warnings.empty();$('#jluxe-import-status').empty();parsed=null;});
  $('#jluxe-import-load-sample').on('click',function(){
    $source.val(JSON.stringify({title:'نام محصول',description:'توضیحات کامل محصول',short_description:'خلاصهٔ کوتاه محصول',categories:['دکوراسیون و تزیینات > آباژور، اکسسوری و دکوری'],brand:'اماهوم',tags:['برچسب اول','برچسب دوم'],specs:[{group:'مشخصات فنی',items:[{label:'ارتفاع',value:'۳۰.۵ سانتی‌متر'},{label:'جنس پایه',value:'چوب گردو'}]}],attributes:[{name:'مشخصه و سایز',value:'آباژور سایز کوچک'},{name:'سیم و کلید',value:'دارد'}],faqs:[{question:'آیا محصول سیم و کلید دارد؟',answer:'بله، محصول دارای سیم و کلید است.'}],seo:{keywords:['کلمه کلیدی اصلی','کلمه کلیدی فرعی'],title:'عنوان سئو',description:'توضیح متای محصول',breadcrumb:'عنوان مسیر'},image_alts:['Alt تصویر شاخص']},null,2));
  });
  $('#jluxe-import-apply').on('click',async function(){if(!parsed&&!$preview.is(':visible'))return;const d=readPreview();const altNow=d.apply_image_alts&&d.image_alts.length?'\n\nتوجه: با تأیید، پنجرهٔ رسانه Alt را فوراً ذخیره می‌کند و این تغییر فقط به ذخیرهٔ محصول موکول نیست.':'';if(!window.confirm('موارد پیش‌نمایش به فیلدهای صفحهٔ محصول منتقل شوند؟ این کار محصول را ذخیره یا منتشر نمی‌کند.'+altNow))return;this.disabled=true;try{await applyAll();}finally{this.disabled=false;}});
  $('#jluxe-import-copy-json').on('click',async function(){try{await navigator.clipboard.writeText(JSON.stringify(readPreview(),null,2));$('#jluxe-import-status').text('JSON پیش‌نمایش کپی شد.');}catch(e){window.alert('دسترسی به کلیپ‌بورد ممکن نشد.');}});
})(jQuery);
