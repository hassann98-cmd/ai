# JLuxe Product SEO/GEO Assistant — Foundation

Status: historical design notes plus current implementation boundary. Plugin v0.12.0 includes the read-only scanner, consented content/SEO workflow, direct GapGPT/Gemini/theme providers, human-reviewed preview/draft saving (instant AI publishing disabled), AI request throttling, bounded operation logs, rollback snapshots, and an opt-in scheduled preview queue. The scheduled queue never applies or publishes. See the historical v0.10.12 implementation section and the v0.12.0 changelog; live WordPress/provider runtime remains unverified.

## Verified JLuxe ↔ GapGPT connection

- The theme's AI settings already include a `gapgpt` provider. In the theme adapter, that provider sets the base URL to `https://api.gapgpt.app/v1` and routes through the existing OpenAI-compatible chat-completions caller; the API key is fetched server-side with the theme's `jluxe_get_ai_api_key()` function. The settings UI stores the key separately and never prints its value to the browser.
- The official quickstart content supplied by the owner confirms `https://api.gapgpt.app/v1` as the OpenAI-compatible base URL, `client.chat.completions.create(...)` as a basic text-generation request, and that model IDs are selected by changing the `model` value. Use only currently listed model IDs and consult model-specific docs for special capabilities. It mentions `https://api.gapapi.com/v1` as an optional CDN route, but the current theme adapter is configured for `api.gapgpt.app`; do not switch hosts without a requirement/test. The theme settings page accepts the model ID.
- The plugin's current `ajax_ai_parse()` already calls `jluxe_get_theme_settings()`, `jluxe_get_ai_api_key()`, and `jluxe_call_ai_provider()` on the server, after its own explicit consent and capability/nonce checks. It disables tools for that extraction request, and sets a conservative temperature/token cap. Therefore, do not add a second GapGPT key field to the plugin: configure the theme once and reuse this adapter.
- The public `/platform-v2` landing route redirects to a login page, but its visible public content lists web search among advanced GapGPT package features. That page does not establish whether web search is exposed through an API endpoint or how to request it.
- The GapGPT n8n guide configures `Authorization: Bearer …` and sends HTTP POST requests to `https://api.gapgpt.app/v1/chat/completions`; it does not document web-search tools or citation payloads. The n8n AI Agent guide uses an n8n `OpenAI Chat Model` with `responsesApiEnabled: false` and a separate n8n Calculator Tool; its mentions of a future knowledge-search tool describe n8n-side orchestration, not GapGPT's native API. The owner also supplied a `POST /v1/responses` / `client.responses.create()` text-generation example for `gapgpt-gemma-26b-a4b`; that example has no web-search tool or source citations. The public GPT-5.6 model guide currently says its documented scope is Chat Completions and does not claim OpenAI Responses-only tool features for GapGPT.
- Therefore API-side browsing is still unverified. Before implementing live web research, obtain GapGPT's exact documented web-search tool/endpoint, supported model identifiers, and the response format for source URLs/citations. Do not guess an OpenAI tool schema or treat a regular answer as researched evidence.
- The normal chat-completions connection is not, by itself, proof of live web search/browsing. Phase 3 must verify whether GapGPT exposes a supported API search capability; if not, use a distinct research/search adapter and provider. Never imply that GapGPT automatically researched the web unless the selected model/API explicitly documents and exposes that capability.

To configure the existing connection: WordPress admin → Zarrin/JLuxe → AI assistant → choose **GapGPT**, enter the API key in the theme's password field, enter the exact model identifier, save, then use the theme's **Test connection** button. Do not send the secret key in chat or place it in plugin JavaScript.

## Decisions captured from the owner

- Research should combine the seller's notes and existing WooCommerce data with web research, prioritizing credible sources and showing source URLs.
- GEO means Generative Engine Optimization: make product information accurate, structured, and useful to answer engines such as ChatGPT and Gemini. It does not mean inventing mentions or promising ranking/citation outcomes.
- First output scope: Rank Math fields and an audit of missing/incomplete Rank Math data. Content/GEO expansion comes after this foundation.
- Both entry points are wanted: a dashboard to find incomplete products and an action on the currently open product.
- Keep existing safety rules: AI requests require clear consent; API keys stay server-side; generate an editable preview; empty values never clear existing values; no automatic save/publish; uncertain facts are labeled or omitted.

## Product experience

### A. Product audit dashboard

Add a WooCommerce Products submenu called **SEO/GEO audit**. It should be read-only and list products with a per-field status:

- Rank Math SEO title
- Meta description
- Focus keyword(s)
- Breadcrumb title
- Permalink/slug (English ASCII slug is the current requested policy)
- Indexability/noindex warning, when detectable
- Rank Math score, only when Rank Math exposes a usable stored score

Filters: missing fields, incomplete products, and all products; pagination; product edit link. The audit must distinguish **missing metadata** from **low Rank Math score**—a score is a hint, not proof of quality.

### B. Current product action

On the product edit page, add **Audit and complete SEO/GEO**. It opens a focused workflow:

1. Show current product fields and the exact gaps found.
2. Ask for seller-only facts in one notes box (dimensions, materials, compatibility, warranty, packaging, etc.).
3. Before any provider call, show consent and say whether notes/product data will be sent to JLuxe's configured AI provider and which research service will be queried.
4. Gather relevant web evidence, retaining URLs, page titles, retrieval time, and short supporting excerpts.
5. Generate a proposed SEO package, separating verified facts, seller-provided facts, and editorial suggestions.
6. Show a field-by-field editable preview with evidence and confidence; no unsupported product claims.
7. Apply only approved nonempty values to the edit form. Never save or publish automatically.

## Rank Math output contract (first release)

Proposed fields:

- Persian product title remains Persian and unchanged unless the user edits it.
- SEO title and meta description: Persian by default, factual, concise, and previewable.
- Focus keyword(s): derived from the actual product and search intent, without claiming search-volume data unless a configured source supplies it.
- Permalink: concise English semantic translation of the product title, lowercase ASCII with hyphens; not a transliteration of Persian. Brand/model names are romanized consistently. This translation affects only the slug, never the product title.
- Breadcrumb title: Persian product-facing label, applied in the Rank Math Advanced sidebar field.

## Settings screen (proposed controls)

1. **AI provider:** use the JLuxe theme's existing provider/model/key by default; do not duplicate or expose its secret.
2. **Web research provider:** provider selector and server-side secret field. This is required because an ordinary chat-completions endpoint does not necessarily have web-browsing access. Provider choice is still open; no search API should be silently assumed.
3. **Source policy:** official manufacturer first; then recognized retailers/documentation; excluded domains; citation requirement; source freshness window.
4. **Prompt profile:** editable system instructions with reset-to-default and versioning. Separate extraction, evidence synthesis, and SEO-writing prompts; treat product text and web pages as untrusted data.
5. **Audit policy:** fields considered required, optional score threshold, product types to include/exclude, and batch size.
6. **Output policy:** Persian content, English semantic slug, confidence threshold, and whether suggestions may be generated for missing optional fields.
7. **Privacy/logging:** minimum retention by default; redact secrets; optional source-only audit log without full prompt/body retention.

## Research and factuality rules

- User notes and the store's own saved data are authoritative for product-specific facts.
- Web research may add only verifiable general facts relevant to the product; it must not infer a product's material, dimensions, certification, origin, compatibility, or warranty from a similar item.
- If sources conflict, show the conflict and do not choose silently.
- Store citations with the generated draft so the seller can inspect them; do not put raw citations into the product copy unless requested.
- No claim of guaranteed Google ranking, AI citation, traffic, or sales.

## Suggested technical shape

- Keep the existing theme AI adapter for generation; add a separate `ResearchProviderInterface` for web search/fetch. Do not couple search to a specific AI vendor.
- Add an audit service that reads WordPress post meta in batches and returns statuses; it must not mutate products.
- Add capability/nonce checks to every admin and AJAX action; scope every query to `product` and the current user's permissions.
- Store settings with WordPress options and sanitize/validate on save. Keep secrets server-side and mask them in the admin UI.
- Use a versioned draft payload containing: `product_id`, `source_notes`, `field_proposals`, `evidence[]`, `confidence`, `warnings[]`, `prompt_version`, and `created_at`.
- Keep generation and apply separate. Apply accepts only explicitly approved fields and returns a report of updated/skipped/uncertain values.

## Delivery phases

### Phase 1 — Read-only audit foundation (implemented in plugin v0.5.0)

The settings page and paginated, read-only product dashboard now inspect Rank Math metadata presence and, when available, the saved score. This phase does not call AI or write product data.

### Phase 2 — Single-product content and SEO draft (implemented in plugin v0.10.3)

The editable package includes long/short description, taxonomy candidates, tags, grouped specs, up to four WooCommerce attributes, FAQs, Rank Math fields, image alts, evidence warnings, and a separate media plan. The long description targets 600+ Persian words only where evidence permits; Markdown tables are converted to semantic HTML. Existing effective Zarrin specs/FAQs remain authoritative. Product facts must come from saved/current product data or seller inputs, never from images or similar products. Image use is optional, requires separate consent, and is limited to up to four attached JPEG/PNG/WebP images. No generation or application step auto-saves/publishes.

Provider selection now preserves the existing JLuxe/theme adapter (including GapGPT) and adds a separate Gemini REST integration. The Gemini key remains server-side; model and prompt are editable in the admin settings.

### Phase 3 — Web evidence (Gemini integration implemented; live test pending)

The plugin can optionally attach Google's documented `google_search` tool to a Gemini request. Admin activation and per-request consent are both required. Returned grounding queries and HTTPS sources are shown separately from product text; model research observations remain in a separate review-only field. Search results are for competitor/topic context only and may not be treated as evidence about the target product. GapGPT's API search/citation contract remains unverified, so web search is not offered for the theme adapter. No live WordPress or API credentials were available to verify runtime behavior.

### Phase 4 — Dashboard-to-draft workflow

Implemented incrementally in v0.6.1/v0.7.0 and retained in v0.10.3: the editor presents two launch buttons and accessible workflow modals. The full-content result opens in an editable review modal; manual text import and auto content remain isolated. Only explicitly reviewed fields are transferred to the product form; empty fields do not clear current values. Product save/publish remains the standard manual WordPress action; there is no bulk auto-apply.

### Phase 5 — GEO and broader content

Expand beyond Rank Math to FAQ/structured data and answer-engine readiness only after evidence storage and review are reliable. Keep theme-specific JLuxe FAQ/specification controls separate from WooCommerce attributes.

## Implementation references checked

- [Gemini API Generate Content guide](https://ai.google.dev/gemini-api/docs/generate-content/get-started) (REST `generateContent`, `x-goog-api-key`, and Google Search tool examples).
- [Gemini Google Search grounding guide](https://ai.google.dev/gemini-api/docs/generate-content/google-search) (`google_search`, grounding queries, chunks and supports).
- [Gemini structured outputs](https://ai.google.dev/gemini-api/docs/structured-output) (JSON schema output; compatibility depends on model/tools).
- [Gemini model list](https://ai.google.dev/gemini-api/docs/models) (current IDs can change; configured model access must be checked by the owner).
- JLuxe theme AI implementation: `inc/theme-settings-ai.php` and `inc/theme-settings.php` in [the Zarrin theme repository](https://github.com/hassann98-cmd/zarrin).
- [GapGPT API platform landing page](https://gapgpt.app/platform-v2) (currently redirects to login; public visible copy mentions web search as a package feature).
- [GapGPT n8n guide](https://gapgpt.app/platform-v2/docs/use-cases/n8n) (Chat Completions endpoint/auth setup).
- [GapGPT n8n AI Agent guide](https://gapgpt.app/platform-v2/docs/use-cases/n8n-ai-agent) (external n8n tool orchestration; uses Chat Model with Responses API disabled in its starter workflow).
- [GapGPT official API quickstart](https://gapgpt.app/platform-v2/docs/quickstart).
- [GapGPT GPT‑5.6 API guide](https://gapgpt.app/platform-v2/docs/models/gpt-5-6) (its current public search snippet explicitly limits that guide to Chat Completions).
- [SerpApi Google Search API](https://serpapi.com/search-api) (server-side Google SERP results, requiring a private API key).
- [Google Custom Search JSON API status](https://developers.google.com/custom-search/v1/overview) (closed to new customers; existing service scheduled to end January 1, 2027).

## Current implementation and verification boundary

Plugin v0.10.11 retains the read-only audit and manual import workflows, adds direct GapGPT Chat Completions settings/testing and Gemini alongside the theme provider, and supports consent-gated Gemini grounding or provider-independent Google SERP research via SerpApi with separately displayed source links. It flags exact repeated long-form blocks within a product description, offers an editable Open Graph/social-card preview, reads explicit specification lines from saved/pasted short descriptions, normalizes duplicate brand rows/highlight limits, gives useful diagnostics when admin-ajax returns HTML instead of a JSON response, and improves consented research outputs for competitor topics and candidate keyword clusters. The search layer is not native GapGPT browsing: it fetches public Google results/pages via a separately configured SerpApi key and passes bounded source material to GapGPT. Static PHP parsing with php-parser, JavaScript syntax checks, UI/key-exposure checks, and Node smoke tests pass. A live WordPress installation, SerpApi key and provider endpoint were not available; therefore installation, live search-page fetches, generation quality, model support, image multimodality and API permissions still require staging/runtime tests.


### v0.10.3 hardening

Server-side preview normalization now enforces SEO character caps, keeps only exact allowlisted HTTPS links to supplied related products, prevents unsupported research notes when no usable citations exist, preserves stored specs while surfacing new nonconflicting AI suggestions for human review, redacts API credentials from generation diagnostics, and fixes whitespace-regex escaping in word counts/excerpts/FAQ normalization. The built-in default prompt is fully schema-aligned; an already-saved custom prompt in WordPress options is deliberately not overwritten by plugin updates.


### v0.10.3 audit follow-up

The legacy manual extraction and SEO-only AJAX handlers now use the shared API-key-redacting error formatter. The SEO-only sanitizer also enforces the same 60/150-character metadata caps as the full-content workflow. Search availability wording in the audit UI now distinguishes the legacy SEO-only path from the consent-gated Gemini full-content path.

### v0.10.4 permalink safety

The generated English slug is preview-only by default. Changing the product URL now requires an explicit checkbox, the original slug is available to restore the Rank Math preview when consent is revoked, and manual edits to the permalink field are synchronized into the server-side save payload. Changing an already indexed URL still requires the site owner to verify a working permanent redirect.

### v0.10.5 content and social review

The read-only audit flags exact duplicate long-form blocks within the same product description as an editorial review heuristic. It does not scan across all products or evaluate truth, originality, ranking, or overall quality. The full-content review now includes separately editable Open Graph/social title and description fields, a preview card, and an explicit optional featured-image checkbox; Rank Math social metadata is written only during the normal manual product save. The image comes from the site's featured-image attachment and is not sent to the AI provider.

### v0.10.6 short-description facts and brand highlight order

Saved and pasted short descriptions are treated as factual sources for explicit label/value specs such as dimensions and measurements. Rich text is converted to plain text with paragraph/list boundaries preserved; the AI prompt includes the excerpt, and the server extracts recognizable spec-like lines deterministically. Conflicts with saved spec values are surfaced for manual review and the original excerpt is retained. When a brand is selected, the theme brand is treated as highlight #1 and the preview allows at most three additional WooCommerce attributes. Matching brand rows in grouped specs are moved after non-brand rows while preserving their values; non-brand saved rows are not dropped.

### v0.10.7 AJAX response diagnostics

Automatic content and manual AI analysis now read AJAX response bodies as text and verify the expected WordPress JSON envelope. If the server returns HTML or a non-WordPress response, the UI reports the HTTP status and sanitized page title rather than the browser's generic `Unexpected token '<'` parse error. This diagnoses but cannot resolve upstream authentication, firewall/CDN, hosting, or PHP failures; those still require a staging retry and the corresponding server logs.

### v0.10.8 research depth and sparse-spec handling

When—and only when—the site owner enables Gemini Google Search and the user separately consents for that request, the system prompt now asks for source-grounded competitor topics, candidate keyword clusters, likely search intent, content gaps, and FAQ ideas. These are provisional ideas; no search-volume, difficulty, ranking, or traffic figures are fabricated. Competitor pages are not allowed as evidence for the target product's specifications. If fewer than three non-brand product specifications are supported by saved/seller data, the plugin warns the editor and asks for seller-confirmed details instead of filling the spec table with guesses. A matching brand row is omitted from the specs preview in that case because the selected taxonomy brand remains saved; non-brand spec rows are preserved. The content prompt asks for richer structured copy when the available evidence genuinely supports it; a length target is not a reason to pad.

### v0.10.11 seller-note structured-fact flow

The server now parses only explicit, allow-listed label/value rows from the seller-notes field (including Markdown table rows and one-fact-per-line formats). Those exact facts are merged into grouped technical specs unless a saved value conflicts; conflicts are surfaced rather than overwritten. Matching available facts are also offered as highlight attributes. If the model omits a parsed fact from generated copy, a factual table is appended to the long description and a concise set to the short description. Free-form prose remains available to the model but is not guessed into a structured field; the editor explains the recommended labeled format and warns when deterministic extraction finds none.

### v0.10.10 seller-note coverage hardening

Seller-provided notes are transmitted once in a clearly labeled final message block, separate from the general product JSON; the system prompt treats them as explicitly verified product facts and requires each relevant fact and exact number/unit to be represented or surfaced as a conflict. The editor reports the note character count sent. Preview checks whether distinct numeric values from the notes occur in the description, short description, specs, attributes or FAQs and raises a warning for any missing values. This is a deterministic reminder, not a semantic guarantee; the editor still reviews each note against the draft.

### v0.10.9 GapGPT depth and Google SERP research

GapGPT direct Chat Completions now receives an explicit `max_tokens=6000` budget instead of depending on the gateway’s unspecified default. The evidence-aware Persian content prompt uses evidence- and category-complexity-based word ranges and does not pad. For provider-independent web research, the site owner can configure a separate SerpApi key (never exposed to the browser). Per-product consent sends only the title/brand/category-derived queries to SerpApi; up to two Google queries are executed, search result metadata is collected, and at most three public HTTPS competitor pages are fetched server-side with safe URL validation, redirects and response-size limits. Snippets/page excerpts are then sent as untrusted research data to the selected AI provider, never as evidence for target-product specs. The preview separately lists queries and source links, marking whether page text was actually fetched. This relies on the SerpApi service and its account quota/cost; it is not native GapGPT browsing and does not provide Google ranking or search-volume measurements.

### v0.10.12 model, automation, and UI update

- Product and admin surfaces received a refreshed style system; grouped front-end specifications use a dedicated stylesheet enqueued only when that product has grouped specs.
- Direct GapGPT defaults to `gpt-6.1-sol` and Responses API with selectable reasoning effort; Chat Completions remains a fallback. A mode-aware text probe checks for an actual response, but neither support for Responses nor honored reasoning level has been live-tested against the owner's account. Gemini's endpoint and test flow remain separate and unchanged.
- Per-product generation defaults to preview. The editor also offers fill-only, save-draft, and immediate publish/update modes. Immediate publish requires separate per-product consent and structural blockers (description length, at least three specs, missed seller-note numbers, known conflicts/incomplete responses, and failed requested research); these checks do not prove factual truth. In automatic field application, title, taxonomy, slug and attachment Alt are not changed.
- A separately consented WP-Cron queue can cover selected products or the whole catalog, checks every six hours, processes at most one product per tick and enforces a hard limit of ten attempted API requests per local day. WP-Cron runs only when site traffic triggers it, so timing is approximate. Images, temporary seller notes and web research are disabled in this background queue. It stores a private review preview only; it never mutates product fields or publishes. Admins can stop the queue, revoke consent, view errors, load a saved preview in the normal editor, or clear/retry it. If consent is revoked during a request, the response is discarded, although provider cost may already have accrued.
- Generation logic was refactored into a reusable service; the background worker calls the service directly rather than impersonating an AJAX request. The worker executes under the consenting manager's current capabilities and stores no API credentials in queue metadata.
- Verification: `node --check assets/importer.js`, parser/content/AJAX/SEO Node smoke tests, key-exposure grep, and PHP 7.4 AST parsing passed. No PHP runtime, actual WordPress install, staging account, API credentials or live provider calls were available; Cron timing, permissions, meta-box behavior, model endpoint support, cost and content quality still require staging verification.
