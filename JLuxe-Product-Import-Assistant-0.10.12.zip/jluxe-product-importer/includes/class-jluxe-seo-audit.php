<?php
/**
 * Read-only Rank Math completeness audit for WooCommerce products.
 *
 * @package JLuxe_Product_Import_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JLuxe_Product_SEO_Audit {
	const OPTION_KEY = 'jluxe_product_seo_audit_settings';
	const PAGE_SLUG  = 'jluxe-product-seo-audit';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	private function defaults(): array {
		return array(
			'require_seo_title'       => 1,
			'require_meta_description'=> 1,
			'require_focus_keyword'   => 1,
			'require_breadcrumb'      => 1,
			'require_english_slug'    => 1,
			'score_threshold'         => 70,
			'extra_instructions'      => '',
		);
	}

	public function add_menu(): void {
		add_submenu_page(
			'edit.php?post_type=product',
			'ممیزی سئوی محصولات',
			'ممیزی سئو',
			'edit_products',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function register_settings(): void {
		register_setting(
			'jluxe_product_seo_audit_group',
			self::OPTION_KEY,
			array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_settings' ), 'default' => $this->defaults() )
		);
	}

	public function sanitize_settings( $input ): array {
		$input    = is_array( $input ) ? $input : array();
		$defaults = $this->defaults();
		$out      = array();
		foreach ( array( 'require_seo_title', 'require_meta_description', 'require_focus_keyword', 'require_breadcrumb', 'require_english_slug' ) as $key ) {
			$out[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
		}
		$out['score_threshold'] = isset( $input['score_threshold'] ) ? max( 0, min( 100, absint( $input['score_threshold'] ) ) ) : $defaults['score_threshold'];
		$extra = isset( $input['extra_instructions'] ) ? sanitize_textarea_field( (string) $input['extra_instructions'] ) : '';
		$out['extra_instructions'] = function_exists( 'mb_substr' ) ? mb_substr( $extra, 0, 3000 ) : substr( $extra, 0, 3000 );
		return $out;
	}

	private function settings(): array {
		return wp_parse_args( get_option( self::OPTION_KEY, array() ), $this->defaults() );
	}

	private function audit_product( int $product_id, array $settings ): array {
		$missing = array();
		$checks  = array(
			'require_seo_title'        => array( 'meta' => '_rank_math_title', 'label' => 'عنوان SEO' ),
			'require_meta_description' => array( 'meta' => '_rank_math_description', 'label' => 'توضیح متا' ),
			'require_focus_keyword'    => array( 'meta' => '_rank_math_focus_keyword', 'label' => 'کلمهٔ کلیدی کانونی' ),
			'require_breadcrumb'       => array( 'meta' => '_rank_math_breadcrumb_title', 'label' => 'عنوان مسیر راهنما' ),
		);
		foreach ( $checks as $setting_key => $check ) {
			if ( empty( $settings[ $setting_key ] ) ) { continue; }
			$value = trim( (string) get_post_meta( $product_id, $check['meta'], true ) );
			if ( '' === $value ) { $missing[] = $check['label']; }
		}
		$slug = (string) get_post_field( 'post_name', $product_id );
		if ( ! empty( $settings['require_english_slug'] ) && ( '' === $slug || ! preg_match( '/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug ) ) ) {
			$missing[] = 'پیوند یکتای لاتین';
		}
		$raw_score = get_post_meta( $product_id, '_rank_math_seo_score', true );
		$score     = is_numeric( $raw_score ) ? (int) $raw_score : null;
		$low_score        = null !== $score && $score > 0 && $score < (int) $settings['score_threshold'];
		$content_warnings = $this->repeated_content_warnings( $product_id );
		return array( 'missing' => $missing, 'score' => $score, 'low_score' => $low_score, 'content_warnings' => $content_warnings );
	}

	/** Flag exact repeated content blocks on the same product page; this is a review heuristic, not a ranking score. */
	private function repeated_content_warnings( int $product_id ): array {
		$content = (string) get_post_field( 'post_content', $product_id );
		if ( '' === trim( $content ) ) { return array(); }
		$blocks = preg_split( '/<\/(?:p|li|h[1-6]|div|tr)>/i', $content );
		if ( ! is_array( $blocks ) ) { return array(); }
		$seen = array();
		foreach ( $blocks as $block ) {
			$block = strip_shortcodes( $block );
			$block = html_entity_decode( wp_strip_all_tags( $block ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) ?: 'UTF-8' );
			$block = preg_replace( '/\s+/u', ' ', trim( $block ) );
			if ( ! is_string( $block ) || '' === $block ) { continue; }
			$length = function_exists( 'mb_strlen' ) ? mb_strlen( $block, 'UTF-8' ) : strlen( $block );
			if ( $length < 100 ) { continue; }
			$normalized = function_exists( 'mb_strtolower' ) ? mb_strtolower( $block, 'UTF-8' ) : strtolower( $block );
			$hash       = hash( 'sha256', $normalized );
			$seen[ $hash ] = isset( $seen[ $hash ] ) ? $seen[ $hash ] + 1 : 1;
		}
		$duplicate_blocks = array_sum( array_map( static function ( $count ) { return max( 0, $count - 1 ); }, $seen ) );
		return $duplicate_blocks > 0 ? array( sprintf( '%d بلوک متنی بلند تکراری در همین صفحه؛ پیش از انتشار بازبینی شود', $duplicate_blocks ) ) : array();
	}

	private function checkbox_row( string $key, string $label, array $settings ): void {
		printf(
			'<label style="display:block;margin:7px 0"><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s> %4$s</label>',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $key ),
			checked( 1, (int) $settings[ $key ], false ),
			esc_html( $label )
		);
	}

	public function render_page(): void {
		if ( ! current_user_can( 'edit_products' ) ) { wp_die( esc_html__( 'اجازهٔ دسترسی ندارید.', 'jluxe-product-importer' ) ); }
		$settings = $this->settings();
		$paged    = max( 1, absint( $_GET['paged'] ?? 1 ) );
		$filter   = isset( $_GET['audit_filter'] ) && 'incomplete' === sanitize_key( wp_unslash( $_GET['audit_filter'] ) ) ? 'incomplete' : 'all';
		$query    = new WP_Query( array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page' => 30,
			'paged'          => $paged,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'no_found_rows'  => false,
		) );
		?>
		<div class="wrap jpi-audit-page" dir="rtl">
			<h1>ممیزی سئوی محصولات</h1>
			<p>این صفحه متادیتای موجود Rank Math را می‌خواند و بلوک‌های بلندِ تکراری را فقط در توضیحات همان محصول بررسی می‌کند؛ هیچ محصولی را تغییر نمی‌دهد، ذخیره یا منتشر نمی‌کند. نبودن یک فیلد سفارشی الزاماً به معنی خراب بودن خروجی نهایی نیست، چون Rank Math ممکن است از الگوهای عمومی سایت استفاده کند.</p>
			<div class="notice notice-info inline"><p><strong>ممیزی خواندنی است:</strong> این صفحه فیلدهای خالی، امتیاز ذخیره‌شده و تکرار عینی متن داخل همان صفحه را گزارش می‌کند؛ تکرار، سنجهٔ کیفیت یا رتبه نیست و بررسی بین محصولات هم نیست. پیش‌نویس SEO مستقل فقط از داده‌های محصول و یادداشت فروشنده استفاده می‌کند؛ پژوهش وب در آن مسیر انجام نمی‌شود. در گردش‌کار جداگانهٔ «تولید کامل محتوا»، Google Search برای Gemini فقط با فعال‌سازی مدیر و رضایت همان درخواست قابل‌استفاده است. کلید اتصال پوسته در افزونه تکرار یا نمایش داده نمی‌شود.</p></div>

			<h2>تنظیمات معیار ممیزی</h2>
			<form method="post" action="options.php" style="background:#fff;border:1px solid #c3c4c7;padding:16px;max-width:850px">
				<?php settings_fields( 'jluxe_product_seo_audit_group' ); ?>
				<?php $this->checkbox_row( 'require_seo_title', 'عنوان SEO سفارشی را لازم بدان', $settings ); ?>
				<?php $this->checkbox_row( 'require_meta_description', 'توضیح متا را لازم بدان', $settings ); ?>
				<?php $this->checkbox_row( 'require_focus_keyword', 'کلمهٔ کلیدی کانونی را لازم بدان', $settings ); ?>
				<?php $this->checkbox_row( 'require_breadcrumb', 'عنوان مسیر راهنما را لازم بدان', $settings ); ?>
				<?php $this->checkbox_row( 'require_english_slug', 'پیوند یکتای لاتین را لازم بدان', $settings ); ?>
				<p><label for="jpi-audit-score-threshold"><strong>حداقل امتیاز Rank Math برای هشدار:</strong></label>
					<input id="jpi-audit-score-threshold" type="number" min="0" max="100" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[score_threshold]" value="<?php echo esc_attr( (string) $settings['score_threshold'] ); ?>" class="small-text"> / 100
					<span class="description">امتیاز خالی یا صفر «نامشخص» محسوب می‌شود، نه امتیاز پایین.</span>
				</p>
				<p><label for="jpi-seo-extra-instructions"><strong>دستورهای تکمیلی تولید SEO (اختیاری):</strong></label><br>
					<textarea id="jpi-seo-extra-instructions" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[extra_instructions]" rows="4" class="large-text" maxlength="3000"><?php echo esc_textarea( $settings['extra_instructions'] ); ?></textarea>
					<span class="description">به پرامپت ایمن پایه افزوده می‌شود؛ جایگزین قواعد ضدحدس و حفظ عنوان فارسی نیست. کلید یا اطلاعات محرمانه وارد نکن.</span>
				</p>
				<?php submit_button( 'ذخیرهٔ معیارها' ); ?>
			</form>

			<h2 style="margin-top:28px">محصولات</h2>
			<form method="get" style="margin:10px 0">
				<input type="hidden" name="post_type" value="product">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>">
				<label for="jpi-audit-filter">نمایش:</label>
				<select id="jpi-audit-filter" name="audit_filter">
					<option value="all" <?php selected( 'all', $filter ); ?>>همهٔ محصولات این صفحه</option>
					<option value="incomplete" <?php selected( 'incomplete', $filter ); ?>>ناقص/نیازمند بررسی در این صفحه</option>
				</select>
				<?php submit_button( 'اعمال فیلتر', 'secondary', '', false ); ?>
			</form>
				<p>در هر صفحه حداکثر ۳۰ محصول، مرتب‌شده بر اساس آخرین ویرایش، بررسی می‌شود. فیلتر «ناقص» روی همین صفحه است. هشدار تکرار فقط بلوک‌های عیناً تکراریِ بلند در توضیحات همان محصول را پیدا می‌کند؛ کیفیت یا رتبه را نمی‌سنجد.</p>
			<table class="widefat striped">
				<thead><tr><th>محصول</th><th>فیلدهای خالی</th><th>امتیاز Rank Math</th><th>هشدار محتوایی (ابتدایی)</th><th>وضعیت</th><th>اقدام</th></tr></thead>
				<tbody>
				<?php
				$shown = 0;
				if ( $query->have_posts() ) :
					while ( $query->have_posts() ) :
						$query->the_post();
						$product_id = get_the_ID();
						$audit      = $this->audit_product( $product_id, $settings );
						$is_incomplete = ! empty( $audit['missing'] ) || ! empty( $audit['low_score'] ) || ! empty( $audit['content_warnings'] );
						if ( 'incomplete' === $filter && ! $is_incomplete ) { continue; }
						$shown++;
						?>
						<tr>
							<td><?php echo esc_html( get_the_title() ); ?><br><small>#<?php echo esc_html( (string) $product_id ); ?> · <?php echo esc_html( get_post_status_object( get_post_status() )->label ?? get_post_status() ); ?></small></td>
							<td><?php echo $audit['missing'] ? esc_html( implode( '، ', $audit['missing'] ) ) : '—'; ?></td>
							<td><?php echo null === $audit['score'] || 0 === $audit['score'] ? 'نامشخص' : esc_html( (string) $audit['score'] . '/100' ); ?></td>
							<td><?php echo $audit['content_warnings'] ? esc_html( implode( '؛ ', $audit['content_warnings'] ) ) : '—'; ?></td>
							<td><?php if ( $audit['missing'] ) : ?><span style="color:#b32d2e">فیلد ناقص</span><?php elseif ( $audit['low_score'] ) : ?><span style="color:#b32d2e">امتیاز پایین</span><?php elseif ( $audit['content_warnings'] ) : ?><span style="color:#996800">بازبینی محتوا</span><?php else : ?><span style="color:#008a20">بدون مورد ناقصِ پیکربندی‌شده</span><?php endif; ?><?php if ( $audit['low_score'] && $audit['missing'] ) : ?><br><span style="color:#b32d2e">امتیاز کمتر از حد</span><?php endif; ?></td>
							<td><?php $edit_url = get_edit_post_link( $product_id, 'url' ); ?><a class="button button-small" href="<?php echo esc_url( $edit_url ); ?>">بازکردن محصول</a> <a class="button button-small" href="<?php echo esc_url( $edit_url . '#jpi-seo-draft-section' ); ?>">رفتن به پیش‌نویس SEO</a></td>
						</tr>
						<?php
					endwhile;
					wp_reset_postdata();
				endif;
				if ( ! $shown ) : ?><tr><td colspan="6">در این صفحه محصولی برای این فیلتر پیدا نشد.</td></tr><?php endif; ?>
				</tbody>
			</table>
			<?php
			$pages = (int) $query->max_num_pages;
			if ( $pages > 1 ) {
				$base = add_query_arg( array( 'post_type' => 'product', 'page' => self::PAGE_SLUG, 'audit_filter' => $filter, 'paged' => '%#%' ), admin_url( 'edit.php' ) );
				echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => $paged, 'total' => $pages ) ) ) . '</div></div>';
			}
			wp_reset_postdata();
			?>
		</div>
		<?php
	}
}
