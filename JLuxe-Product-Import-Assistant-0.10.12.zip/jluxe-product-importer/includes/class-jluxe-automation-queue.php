<?php
/** Consent-gated scheduled content previews for selected WooCommerce products. */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class JLuxe_Product_Automation_Queue {
	const OPTION_KEY = 'jluxe_product_automation_queue';
	const USAGE_KEY  = 'jluxe_product_automation_queue_usage';
	const CRON_HOOK  = 'jluxe_product_automation_queue_tick';
	const CRON_SCHEDULE = 'jpi_every_six_hours';
	const DAILY_LIMIT = 10;

	private $generator;

	public function __construct( JLuxe_Product_Content_Draft $generator ) {
		$this->generator = $generator;
		add_filter( 'cron_schedules', array( $this, 'add_cron_schedule' ) );
		add_action( 'init', array( $this, 'ensure_schedule' ) );
		add_action( self::CRON_HOOK, array( $this, 'process_one' ) );
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_jpi_queue_save', array( $this, 'save_settings' ) );
		add_action( 'admin_post_jpi_queue_run_one', array( $this, 'run_one_now' ) );
		add_action( 'admin_post_jpi_queue_clear_preview', array( $this, 'clear_preview' ) );
	}

	public static function deactivate(): void {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		delete_option( 'jpi_product_queue_lock' );
	}

	public static function defaults(): array {
		return array( 'enabled' => 0, 'scope' => 'selected', 'product_ids' => array(), 'user_id' => 0, 'consented_at' => 0, 'cursor' => 0 );
	}

	public static function get_settings(): array {
		$saved = get_option( self::OPTION_KEY, array() );
		$settings = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		$settings['enabled'] = empty( $settings['enabled'] ) ? 0 : 1;
		$settings['scope'] = in_array( (string) $settings['scope'], array( 'selected', 'all' ), true ) ? (string) $settings['scope'] : 'selected';
		$settings['product_ids'] = array_values( array_unique( array_filter( array_map( 'absint', is_array( $settings['product_ids'] ) ? $settings['product_ids'] : array() ) ) ) );
		$settings['user_id'] = absint( $settings['user_id'] );
		$settings['cursor'] = absint( $settings['cursor'] );
		return $settings;
	}

	public function add_cron_schedule( array $schedules ): array {
		$schedules[ self::CRON_SCHEDULE ] = array( 'interval' => 6 * HOUR_IN_SECONDS, 'display' => 'Every six hours (JLuxe product preview queue)' );
		return $schedules;
	}

	public function ensure_schedule(): void {
		$settings = self::get_settings();
		if ( empty( $settings['enabled'] ) ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			return;
		}
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 90, self::CRON_SCHEDULE, self::CRON_HOOK );
		}
	}

	public function add_menu(): void {
		add_submenu_page(
			'edit.php?post_type=product',
			'صف بازبینی خودکار محتوا',
			'صف بازبینی خودکار',
			'manage_options',
			'jluxe-product-automation-queue',
			array( $this, 'render_page' )
		);
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$settings = self::get_settings();
		$notice = isset( $_GET['jpi_queue_notice'] ) ? sanitize_key( wp_unslash( $_GET['jpi_queue_notice'] ) ) : '';
		$usage = $this->get_usage();
		$all_products = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => 100, 'orderby' => 'modified', 'order' => 'DESC', 'fields' => 'all' ) );
		$review_ids = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => 100, 'orderby' => 'modified', 'order' => 'DESC', 'fields' => 'ids', 'meta_key' => '_jpi_scheduled_preview' ) );
		$error_ids = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => 50, 'orderby' => 'modified', 'order' => 'DESC', 'fields' => 'ids', 'meta_key' => '_jpi_queue_error' ) );
		?>
		<div class="wrap jpi-settings-page jpi-queue-page" dir="rtl">
			<h1>صف بازبینی خودکار محتوا</h1>
			<p>این صف هر ۶ ساعت حداکثر یک کالا را پردازش می‌کند؛ سقف سخت مصرف ۱۰ درخواست در روز است. WP-Cron به بازدیدهای سایت وابسته است و اجرای دقیق در ساعت مشخص تضمین نمی‌شود. توقف اضطراری کارهای جدید را متوقف می‌کند؛ درخواست API که از قبل در حال اجراست قابل پس‌گرفتن نیست، اما در صورت لغو رضایت، پاسخ آن ذخیره نخواهد شد. حالت صف همیشه «تولید پیش‌نمایش» است: هیچ توضیح، مشخصه، SEO، وضعیت انتشار یا رسانه‌ای خودکار ذخیره/تغییر نمی‌شود.</p>
			<?php if ( 'saved' === $notice ) : ?><div class="notice notice-success is-dismissible"><p>تنظیمات صف ذخیره شد.</p></div><?php elseif ( 'paused' === $notice ) : ?><div class="notice notice-warning is-dismissible"><p>توقف اضطراری فعال شد؛ رویداد زمان‌بندی‌شده پاک شد.</p></div><?php elseif ( 'ran' === $notice ) : ?><div class="notice notice-info is-dismissible"><p>درخواست اجرای دستی ثبت شد؛ اگر صف فعال، سهمیهٔ روزانه باقی‌مانده و محصول واجدشرایط موجود باشد، یک کار انجام می‌شود. نتیجه یا دلیل توقف را در وضعیت/خطاهای صف بررسی کنید.</p></div><?php elseif ( 'cleared' === $notice ) : ?><div class="notice notice-success is-dismissible"><p>پیش‌نمایش ذخیره‌شده پاک شد؛ محصول می‌تواند دوباره در صف قرار گیرد.</p></div><?php endif; ?>
			<div class="jpi-queue-status-cards">
				<div><strong><?php echo esc_html( $settings['enabled'] ? 'فعال' : 'متوقف' ); ?></strong><span>وضعیت اضطراری صف</span></div>
				<div><strong><?php echo esc_html( (string) $usage['count'] . ' / ' . self::DAILY_LIMIT ); ?></strong><span>درخواست مصرف‌شدهٔ امروز</span></div>
				<div><strong><?php echo esc_html( (string) count( $review_ids ) ); ?></strong><span>پیش‌نمایش آمادهٔ بازبینی</span></div>
				<div><strong>هر ۶ ساعت</strong><span>حداکثر یک محصول در هر نوبت</span></div>
			</div>
			<section class="jpi-queue-card">
				<h2>تنظیم دامنه و کلید توقف اضطراری</h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="jpi_queue_save">
					<?php wp_nonce_field( 'jpi_queue_save' ); ?>
					<p><label><input type="checkbox" name="enabled" value="1" <?php checked( 1, $settings['enabled'] ); ?>> صف زمان‌بندی‌شده را فعال نگه دار</label></p>
					<p><label for="jpi-queue-scope"><strong>دامنهٔ صف</strong></label><br><select id="jpi-queue-scope" name="scope"><option value="selected" <?php selected( 'selected', $settings['scope'] ); ?>>فقط محصولات انتخاب‌شده</option><option value="all" <?php selected( 'all', $settings['scope'] ); ?>>کل کاتالوگ محصولات (هر محصولی که تا کنون پیش‌نمایشِ بازبینی‌نشده ندارد)</option></select></p>
					<p class="description">جست‌وجوی وب، SerpApi و ارسال تصویر در صف پس‌زمینه خاموش‌اند. فقط اطلاعات ذخیره‌شدهٔ محصول و محصولات مرتبط برای provider فعال فرستاده می‌شود. برای پژوهش وب و ارسال تصویر از گردش‌کار تکیِ دارای رضایت جداگانه استفاده کنید. پاسخ AI تا زمان پاک‌کردن/بازبینی در متادیتای همان محصول نگه داشته می‌شود.</p>
					<fieldset class="jpi-queue-product-picker"><legend><strong>انتخاب محصولات (برای دامنهٔ «فقط محصولات انتخاب‌شده»)</strong></legend>
						<?php if ( $all_products ) : foreach ( $all_products as $product_post ) : ?>
							<label><input type="checkbox" name="product_ids[]" value="<?php echo esc_attr( (string) $product_post->ID ); ?>" <?php checked( in_array( (int) $product_post->ID, $settings['product_ids'], true ) ); ?>> <span><?php echo esc_html( get_the_title( $product_post ) ?: '(بدون عنوان)' ); ?></span> <small>#<?php echo esc_html( (string) $product_post->ID ); ?> · <?php echo esc_html( $product_post->post_status ); ?></small></label>
						<?php endforeach; foreach ( $settings['product_ids'] as $saved_id ) : if ( ! in_array( $saved_id, array_map( static function( $item ) { return (int) $item->ID; }, $all_products ), true ) ) : ?><label><input type="checkbox" name="product_ids[]" value="<?php echo esc_attr( (string) $saved_id ); ?>" checked> محصول ذخیره‌شده خارج از فهرست اخیر #<?php echo esc_html( (string) $saved_id ); ?></label><?php endif; endforeach; else : ?><p>محصولی در کاتالوگ پیدا نشد.</p><?php endif; ?>
					</fieldset>
					<p><label for="jpi-queue-extra-ids"><strong>شناسهٔ محصولات خارج از فهرست بالا (اختیاری)</strong></label><br><input id="jpi-queue-extra-ids" class="regular-text" type="text" name="extra_product_ids" dir="ltr" placeholder="مثال: 125, 308, 911"><span class="description">ID را از نشانی ویرایش محصول در بخش <code>post=...</code> بردارید؛ چند ID را با ویرگول جدا کنید.</span></p>
					<label class="jpi-queue-consent"><input type="checkbox" name="queue_consent" value="1" <?php checked( ! empty( $settings['consented_at'] ) ); ?>> رضایت می‌دهم عنوان، توضیح کامل/کوتاه، دسته، برند، برچسب‌ها، مشخصات و FAQ ذخیره‌شده، فیلدهای SEO، نام فروشگاه و عنوان/URL حداکثر ۱۲ محصول منتشرشدهٔ هم‌دسته، برای ساخت پیش‌نمایش به provider AI ذخیره‌شده ارسال شود؛ در دامنهٔ «کل کاتالوگ»، محصولات جدید هم تا وقتی صف فعال است می‌توانند وارد پردازش شوند. جست‌وجوی وب، یادداشت‌های موقت و ارسال تصویر در صف خاموش است. ممکن است هزینهٔ متغیر API داشته باشد؛ سقف ۱۰ درخواست روزانه سقف مبلغ پولی نیست. فیلدهای قابل‌نمایش محصول یا وضعیت انتشار تغییر نمی‌کنند؛ پیش‌نمایش موقت در متادیتای خصوصی محصول نگه‌داری می‌شود تا پاک شود.</label>
					<?php submit_button( 'ذخیره و اعمال تنظیمات صف', 'primary', 'submit', false ); ?>
				</form>
				<form class="jpi-queue-run-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="jpi_queue_run_one"><?php wp_nonce_field( 'jpi_queue_run_one' ); ?>
					<?php submit_button( 'اجرای دستی یک محصول از صف (ممکن است هزینه داشته باشد)', 'secondary', 'submit', false, array( 'disabled' => empty( $settings['enabled'] ) ? 'disabled' : false ) ); ?>
				</form>
			</section>
			<section class="jpi-queue-card">
				<h2>پیش‌نمایش‌های زمان‌بندی‌شده برای بازبینی</h2>
				<?php if ( $review_ids ) : ?><div class="jpi-queue-review-list">
					<?php foreach ( $review_ids as $review_id ) : $preview = get_post_meta( $review_id, '_jpi_scheduled_preview', true ); if ( ! is_array( $preview ) ) { continue; } $generated_at = absint( get_post_meta( $review_id, '_jpi_queue_last_run', true ) ); ?>
						<article><div><strong><?php echo esc_html( get_the_title( $review_id ) ); ?></strong><small><?php echo esc_html( 'محصول #' . $review_id . ' · تولید: ' . ( $generated_at ? wp_date( 'Y-m-d H:i', $generated_at ) : 'نامشخص' ) ); ?></small><span>مشخصات: <?php echo esc_html( (string) array_sum( array_map( static function( $group ) { return is_array( $group['items'] ?? null ) ? count( $group['items'] ) : 0; }, is_array( $preview['specs'] ?? null ) ? $preview['specs'] : array() ) ) ); ?> · <?php echo ! empty( $preview['publish_ready'] ) ? 'از دروازهٔ ساختاری گذشت؛ انتشار خودکار انجام نشده' : 'نیازمند بازبینی؛ دروازهٔ کیفیت انتشار را پاس نکرد'; ?></span></div><div><a class="button" href="<?php echo esc_url( get_edit_post_link( $review_id, 'raw' ) . '#jluxe-product-import-assistant' ); ?>">بازکردن و بازبینی</a><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="jpi_queue_clear_preview"><input type="hidden" name="product_id" value="<?php echo esc_attr( (string) $review_id ); ?>"><?php wp_nonce_field( 'jpi_queue_clear_' . $review_id ); ?><button class="button-link-delete" type="submit" onclick="return confirm('پیش‌نمایش ذخیره‌شده پاک شود؟');">پاک‌کردن/آماده‌سازی مجدد</button></form></div></article>
					<?php endforeach; ?>
				</div><?php else : ?><p>پیش‌نمایش آماده‌ای وجود ندارد.</p><?php endif; ?>
			</section>
			<?php if ( $error_ids ) : ?><section class="jpi-queue-card"><h2>خطاهای آخرین اجرا</h2><div class="jpi-queue-review-list"><?php foreach ( $error_ids as $error_id ) : ?><article><div><strong><?php echo esc_html( get_the_title( $error_id ) ); ?></strong><small><?php echo esc_html( 'محصول #' . $error_id . ' · ' . ( get_post_meta( $error_id, '_jpi_queue_last_run', true ) ? wp_date( 'Y-m-d H:i', absint( get_post_meta( $error_id, '_jpi_queue_last_run', true ) ) ) : 'زمان نامشخص' ) ); ?></small><span><?php echo esc_html( get_post_meta( $error_id, '_jpi_queue_error', true ) ); ?></span></div><a class="button" href="<?php echo esc_url( get_edit_post_link( $error_id, 'raw' ) ); ?>">بررسی محصول</a></article><?php endforeach; ?></div></section><?php endif; ?>
		</div>
		<?php
	}

	public function save_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'اجازهٔ انجام این کار را ندارید.' ); }
		check_admin_referer( 'jpi_queue_save' );
		$current = self::get_settings();
		$enabled = ! empty( $_POST['enabled'] ) && '1' === (string) wp_unslash( $_POST['enabled'] );
		$scope = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : 'selected';
		$scope = in_array( $scope, array( 'selected', 'all' ), true ) ? $scope : 'selected';
		$consent = ! empty( $_POST['queue_consent'] ) && '1' === (string) wp_unslash( $_POST['queue_consent'] );
		$ids = isset( $_POST['product_ids'] ) && is_array( $_POST['product_ids'] ) ? array_map( 'absint', wp_unslash( $_POST['product_ids'] ) ) : array();
		$extra_ids_text = isset( $_POST['extra_product_ids'] ) && is_scalar( $_POST['extra_product_ids'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['extra_product_ids'] ) ) : '';
		if ( '' !== $extra_ids_text ) { $ids = array_merge( $ids, array_map( 'absint', preg_split( '/[,،\s]+/u', $extra_ids_text, -1, PREG_SPLIT_NO_EMPTY ) ) ); }
		$ids = array_slice( array_values( array_unique( array_filter( $ids ) ) ), 0, 500 );
		$ids = array_values( array_filter( $ids, static function( $id ) { return 'product' === get_post_type( $id ); } ) );
		$enabled = $enabled && $consent;
		$settings = array(
			'enabled' => $enabled ? 1 : 0,
			'scope' => $scope,
			'product_ids' => $ids,
			'user_id' => $consent ? get_current_user_id() : 0,
			'consented_at' => $consent ? time() : 0,
		);
		update_option( self::OPTION_KEY, $settings, false );
		if ( 'selected' === $scope ) {
			foreach ( $ids as $id ) {
				if ( ! get_post_meta( $id, '_jpi_queue_status', true ) ) { update_post_meta( $id, '_jpi_queue_status', 'pending' ); update_post_meta( $id, '_jpi_queue_next_run', time() ); }
			}
		}
		wp_clear_scheduled_hook( self::CRON_HOOK );
		if ( $enabled ) { wp_schedule_event( time() + 90, self::CRON_SCHEDULE, self::CRON_HOOK ); }
		wp_safe_redirect( add_query_arg( array( 'post_type' => 'product', 'page' => 'jluxe-product-automation-queue', 'jpi_queue_notice' => $enabled ? 'saved' : 'paused' ), admin_url( 'edit.php' ) ) );
		exit;
	}

	public function run_one_now(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'اجازهٔ انجام این کار را ندارید.' ); }
		check_admin_referer( 'jpi_queue_run_one' );
		$this->process_one();
		wp_safe_redirect( add_query_arg( array( 'post_type' => 'product', 'page' => 'jluxe-product-automation-queue', 'jpi_queue_notice' => 'ran' ), admin_url( 'edit.php' ) ) );
		exit;
	}

	public function clear_preview(): void {
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $product_id || 'product' !== get_post_type( $product_id ) ) { wp_die( 'اجازهٔ انجام این کار را ندارید.' ); }
		check_admin_referer( 'jpi_queue_clear_' . $product_id );
		delete_post_meta( $product_id, '_jpi_scheduled_preview' );
		delete_post_meta( $product_id, '_jpi_queue_error' );
		update_post_meta( $product_id, '_jpi_queue_status', 'pending' );
		update_post_meta( $product_id, '_jpi_queue_next_run', time() );
		wp_safe_redirect( add_query_arg( array( 'post_type' => 'product', 'page' => 'jluxe-product-automation-queue', 'jpi_queue_notice' => 'cleared' ), admin_url( 'edit.php' ) ) );
		exit;
	}

	/** Process at most one consented preview per scheduled tick; never apply or publish product data. */
	public function process_one(): void {
		$settings = self::get_settings();
		if ( empty( $settings['enabled'] ) || empty( $settings['consented_at'] ) ) { return; }
		$this->recover_stale_jobs();
		if ( ! $this->acquire_lock() ) { return; }
		$usage = $this->get_usage();
		if ( (int) $usage['count'] >= self::DAILY_LIMIT ) { $this->release_lock(); return; }
		$product_id = $this->next_eligible_product( $settings );
		if ( ! $product_id ) { $this->release_lock(); return; }
		$user_id = absint( $settings['user_id'] );
		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) || ! user_can( $user_id, 'edit_post', $product_id ) ) {
			update_post_meta( $product_id, '_jpi_queue_status', 'error' );
			update_post_meta( $product_id, '_jpi_queue_error', 'حساب مدیرِ رضایت‌دهنده دیگر مجوز لازم ندارد؛ تنظیم صف را با حساب مدیر فعال بازبینی کنید.' );
			update_post_meta( $product_id, '_jpi_queue_next_run', time() + 6 * HOUR_IN_SECONDS );
			$this->release_lock();
			return;
		}
		$old_user_id = get_current_user_id();
		try {
			wp_set_current_user( $user_id );
			if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); }
			update_post_meta( $product_id, '_jpi_queue_status', 'processing' );
			update_post_meta( $product_id, '_jpi_queue_started_at', time() );
			$this->increment_usage(); // Count attempts, including provider failures, toward the hard daily cap.
			$request = array( 'consent' => '1', 'product_id' => (string) $product_id, 'use_images' => '0', 'use_web_research' => '0', 'notes' => '', 'english_model' => '', 'target_audience' => '', 'advantages' => '', 'visual_notes' => '' );
			$result = $this->generator->generate_scheduled_preview( $product_id, $request );
			$latest_settings = self::get_settings();
			$still_consented = ! empty( $latest_settings['enabled'] ) && ! empty( $latest_settings['consented_at'] ) && absint( $latest_settings['user_id'] ) === $user_id && ( 'all' === $latest_settings['scope'] || in_array( $product_id, $latest_settings['product_ids'], true ) );
			$now = time();
			update_post_meta( $product_id, '_jpi_queue_last_run', $now );
			if ( ! $still_consented ) {
				update_post_meta( $product_id, '_jpi_queue_status', 'pending' );
				update_post_meta( $product_id, '_jpi_queue_error', 'توقف صف یا لغو رضایت هنگام اجرای API ثبت شد؛ پاسخ تولیدشده ذخیره نشد. ممکن است هزینهٔ درخواست مصرف شده باشد.' );
				delete_post_meta( $product_id, '_jpi_scheduled_preview' );
				return;
			}
			update_post_meta( $product_id, '_jpi_queue_next_run', $now + 6 * HOUR_IN_SECONDS );
			if ( is_wp_error( $result ) ) {
				$message = JLuxe_Product_Import_Assistant::safe_ai_error( $result );
				update_post_meta( $product_id, '_jpi_queue_status', 'error' );
				update_post_meta( $product_id, '_jpi_queue_error', $message );
				delete_post_meta( $product_id, '_jpi_scheduled_preview' );
			} else {
				update_post_meta( $product_id, '_jpi_scheduled_preview', $result );
				update_post_meta( $product_id, '_jpi_queue_status', 'review' );
				delete_post_meta( $product_id, '_jpi_queue_error' );
			}
		} catch ( Throwable $error ) {
			update_post_meta( $product_id, '_jpi_queue_status', 'error' );
			update_post_meta( $product_id, '_jpi_queue_error', 'پردازش صف به‌دلیل خطای داخلی متوقف شد؛ گزارش خطای PHP هاست را بررسی کنید.' );
			update_post_meta( $product_id, '_jpi_queue_last_run', time() );
			update_post_meta( $product_id, '_jpi_queue_next_run', time() + 6 * HOUR_IN_SECONDS );
		} finally {
			delete_post_meta( $product_id, '_jpi_queue_started_at' );
			wp_set_current_user( $old_user_id );
			$this->release_lock();
		}
	}

	private function acquire_lock(): bool {
		$existing = get_option( 'jpi_product_queue_lock', array() );
		$started = is_array( $existing ) ? absint( $existing['started'] ?? 0 ) : 0;
		if ( $started && $started > time() - 20 * MINUTE_IN_SECONDS ) { return false; }
		if ( false !== $existing ) { delete_option( 'jpi_product_queue_lock' ); }
		return add_option( 'jpi_product_queue_lock', array( 'started' => time() ), '', false );
	}

	private function release_lock(): void {
		delete_option( 'jpi_product_queue_lock' );
	}

	private function recover_stale_jobs(): void {
		$ids = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => 100, 'fields' => 'ids', 'meta_key' => '_jpi_queue_status', 'meta_value' => 'processing' ) );
		$cutoff = time() - 20 * MINUTE_IN_SECONDS;
		foreach ( $ids as $id ) {
			$started = absint( get_post_meta( $id, '_jpi_queue_started_at', true ) );
			if ( $started && $started > $cutoff ) { continue; }
			update_post_meta( $id, '_jpi_queue_status', 'error' );
			update_post_meta( $id, '_jpi_queue_error', 'اجرای قبلی بیش از ۲۰ دقیقه باز ماند یا توسط سرور متوقف شد؛ درخواست به‌طور خودکار تکرار نشده است. برای تلاش دوباره، خطا را از صف پاک/آماده‌سازی مجدد کنید.' );
			update_post_meta( $id, '_jpi_queue_last_run', $started ?: time() );
			update_post_meta( $id, '_jpi_queue_next_run', time() + 6 * HOUR_IN_SECONDS );
			delete_post_meta( $id, '_jpi_queue_started_at' );
		}
	}

	private function next_eligible_product( array $settings ): int {
		$now = time();
		if ( 'all' === $settings['scope'] ) {
			global $wpdb;
			$cursor = absint( $settings['cursor'] );
			$id = $this->query_all_candidate( $cursor, $now );
			if ( ! $id && $cursor ) { $cursor = 0; $id = $this->query_all_candidate( 0, $now ); }
			if ( $id ) { $settings['cursor'] = $id; update_option( self::OPTION_KEY, $settings, false ); }
			return $id;
		}
		foreach ( $settings['product_ids'] as $id ) {
			$id = absint( $id );
			if ( ! $id || 'product' !== get_post_type( $id ) ) { continue; }
			$status = (string) get_post_meta( $id, '_jpi_queue_status', true );
			if ( 'review' === $status || 'processing' === $status ) { continue; }
			$next = absint( get_post_meta( $id, '_jpi_queue_next_run', true ) );
			if ( $next && $next > $now ) { continue; }
			return $id;
		}
		return 0;
	}

	/** Find one eligible product without truncating large catalogs at a fixed page size. */
	private function query_all_candidate( int $cursor, int $now ): int {
		global $wpdb;
		$sql = "SELECT DISTINCT p.ID FROM {$wpdb->posts} AS p LEFT JOIN {$wpdb->postmeta} AS state_meta ON ( state_meta.post_id = p.ID AND state_meta.meta_key = '_jpi_queue_status' ) LEFT JOIN {$wpdb->postmeta} AS next_meta ON ( next_meta.post_id = p.ID AND next_meta.meta_key = '_jpi_queue_next_run' ) WHERE p.post_type = %s AND p.post_status IN ('publish','draft','pending','private','future') AND p.ID > %d AND ( state_meta.meta_id IS NULL OR state_meta.meta_value NOT IN ('review','processing') ) AND ( next_meta.meta_id IS NULL OR CAST(next_meta.meta_value AS UNSIGNED) <= %d ) ORDER BY p.ID ASC LIMIT 1";
		return absint( $wpdb->get_var( $wpdb->prepare( $sql, 'product', $cursor, $now ) ) );
	}

	private function get_usage(): array {
		$usage = get_option( self::USAGE_KEY, array() );
		$today = wp_date( 'Y-m-d' );
		if ( ! is_array( $usage ) || ( $usage['date'] ?? '' ) !== $today ) { return array( 'date' => $today, 'count' => 0 ); }
		return array( 'date' => $today, 'count' => absint( $usage['count'] ?? 0 ) );
	}

	private function increment_usage(): void {
		$usage = $this->get_usage();
		$usage['count']++;
		update_option( self::USAGE_KEY, $usage, false );
	}
}
